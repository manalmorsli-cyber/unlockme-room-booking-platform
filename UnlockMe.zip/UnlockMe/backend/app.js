const express = require("express");
const path = require("path");
const app = express();
const cors = require("cors"); // Ajoutez cette ligne



// Middleware CORS - AUTORISEZ VOTRE FRONTEND
// app.use(cors({
//   origin: "http://127.0.0.1:5500", // ou "http://localhost:5500"
//   credentials: true
// }));
// Ajouter d'autres liens d'acces
app.use(cors({
  origin: ["http://127.0.0.1:5500", "http://localhost:5500", "http://localhost:3001"],
  credentials: true
}));

// Middleware JSON
app.use(express.json());
//Servir les fichiers statiques (IMAGES)
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));

// 🔴 AJOUT OBLIGATOIRE
const geocodeRoutes = require('./routes/geocode');
app.use('/api/geocode', geocodeRoutes);


// Routes Auth
const authRoutes = require("./routes/auth.routes");
app.use("/api/auth", authRoutes);

// Route test
app.get("/", (req, res) => {
  res.send("Room Booking API is running");
});

const testRoutes = require("./routes/test.routes");
app.use("/api/test", testRoutes);

const roomRoutes = require("./routes/room.routes");
app.use("/api/rooms", roomRoutes);

const bookingRoutes = require("./routes/booking.routes");
app.use("/api/bookings", bookingRoutes);

// NOUVELLE ROUTE REVIEWS
const reviewRoutes = require("./routes/review.routes");
app.use("/api/reviews", reviewRoutes);


module.exports = app;

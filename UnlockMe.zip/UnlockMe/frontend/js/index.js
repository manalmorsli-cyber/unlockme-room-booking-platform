const API = "http://localhost:3000/api";
let map = null;
let markers = [];
let allRooms = [];
let markerCluster = null;

// Coordonnées des villes algeriennes principales
const ALGERIAN_CITIES_COORDS = {
  'alger': { lat: 36.7538, lng: 3.0588, name: 'Alger' },
  'oran': { lat: 35.6971, lng: -0.6337, name: 'Oran' },
  'constantine': { lat: 36.3650, lng: 6.6147, name: 'Constantine' },
  'annaba': { lat: 36.9000, lng: 7.7667, name: 'Annaba' },
  'batna': { lat: 35.5550, lng: 6.1741, name: 'Batna' },
  'blida': { lat: 36.4700, lng: 2.8300, name: 'Blida' },
  'setif': { lat: 36.1900, lng: 5.4100, name: 'Sétif' },
  'sidi bel abbes': { lat: 35.1939, lng: -0.6414, name: 'Sidi Bel Abbès' },
  'biskra': { lat: 34.8500, lng: 5.7333, name: 'Biskra' },
  'tebessa': { lat: 35.4000, lng: 8.1167, name: 'Tebessa' },
  'tiaret': { lat: 35.3667, lng: 1.3167, name: 'Tiaret' },
  'bejaia': { lat: 36.7500, lng: 5.0667, name: 'Bejaïa' },
  'tlemcen': { lat: 34.8828, lng: -1.3167, name: 'Tlemcen' },
  'bechar': { lat: 31.6082, lng: -2.2198, name: 'Bechar' },
  'skikda': { lat: 36.8667, lng: 6.9000, name: 'Skikda' },
  'souk ahras': { lat: 36.2864, lng: 7.9511, name: 'Souk Ahras' },
  'msila': { lat: 35.7058, lng: 4.5419, name: 'M\'Sila' },
  'el oued': { lat: 33.3683, lng: 6.8672, name: 'El Oued' },
  'laghouat': { lat: 33.8000, lng: 2.8650, name: 'Laghouat' },
  'ouargla': { lat: 31.9500, lng: 5.3167, name: 'Ouargla' },
  'mostaganem': { lat: 35.9333, lng: 0.0833, name: 'Mostaganem' },
  'medea': { lat: 36.2675, lng: 2.7500, name: 'Médéa' },
  'tizi ouzou': { lat: 36.7167, lng: 4.0500, name: 'Tizi Ouzou' },
  'jijel': { lat: 36.8206, lng: 5.7667, name: 'Jijel' },
  'saida': { lat: 34.8303, lng: 0.1517, name: 'Saïda' },
  'guelma': { lat: 36.4619, lng: 7.4258, name: 'Guelma' }
};

function clearGeocodeCache() {
  const keys = Object.keys(localStorage);
  keys.forEach(key => {
    if (key.startsWith('geocode_')) {
      localStorage.removeItem(key);
    }
  });
  console.log("Cache géocodage effacé");
}

async function loadPublicRooms() {
  try {
    clearGeocodeCache();
    
    const res = await fetch(`${API}/rooms`);
    allRooms = await res.json();
    
    renderRoomsSlider(allRooms);
    
    
    allRooms = allRooms.map(room => {
      if (room.location?.address) {
        room.location.address = room.location.address.trim();
      }
      
      
      if (room.location?.lat === 36.75 && room.location?.lng === 3.06) {
        console.log(`Suppression coordonnées par défaut pour: ${room.title}`);
        delete room.location.lat;
        delete room.location.lng;
      }
      
      return room;
    });
    
    debugRooms(allRooms);
    diagnoseAddressIssues();
    renderRoomsSlider(allRooms);
    initMap(allRooms);
  } catch (error) {
    console.error("Erreur:", error);
    const container = document.getElementById('rooms-container');
    container.innerHTML = `
      <div class="alert alert-danger">
        Impossible de charger les salles. Vérifiez la connexion au serveur.
      </div>
    `;
  }
}

function diagnoseAddressIssues() {
  console.log("=== DIAGNOSTIC ADRESSES ===");
  
  allRooms.forEach((room, i) => {
    const addr = room.location?.address || 'N/A';
    const city = detectCityFromAddress(addr);
    const coords = getExactCoordinatesForAddress(addr, room._id);
    
    console.log(`${i+1}. "${addr}" -> Ville: ${city || 'Non détectée'} -> Coord: ${coords.lat}, ${coords.lng}`);
  });
}

function debugRooms(rooms) {
  console.log("=== DEBUG ROOMS ===");
  console.log(`Total salles: ${rooms.length}`);
  
  rooms.forEach((room, index) => {
    console.log(`Salle ${index + 1}: ${room.title}`);
    console.log(`  - Adresse: ${room.location?.address || 'N/A'}`);
    console.log(`  - Lat: ${room.location?.lat || 'N/A'}`);
    console.log(`  - Lng: ${room.location?.lng || 'N/A'}`);
    console.log(`  - Images: ${room.images ? room.images.length : 0} image(s)`);
  });
  
  const roomsWithCoords = rooms.filter(r => r.location?.lat && r.location?.lng);
  console.log(`Salles avec coordonnées: ${roomsWithCoords.length}/${rooms.length}`);
  
  const roomsWithImages = rooms.filter(r => r.images && r.images.length > 0);
  console.log(`Salles avec images: ${roomsWithImages.length}/${rooms.length}`);
}

function initMap(rooms) {
  if (map) {
    map.remove();
  }
  
  // Vue initiale sur l'Algerie
  map = L.map('map').setView([28.0, 2.0], 5);
  
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap'
  }).addTo(map);
  
  markerCluster = L.markerClusterGroup({
    spiderfyOnMaxZoom: true,
    showCoverageOnHover: false,
    zoomToBoundsOnClick: true,
    maxClusterRadius: 50
  });
  
  map.addLayer(markerCluster);
  
  addMarkersWithGeocoding(rooms);
}

async function addMarkersWithGeocoding(rooms) {
  console.log("=== GÉOCODAGE ET AJOUT DES MARQUEURS ===");
  
  if (markerCluster) {
    markerCluster.clearLayers();
  }
  markers = [];
  
  
  for (const room of rooms) {
    const address = room.location?.address || '';
    console.log(`Traitement salle: "${room.title}" -> Adresse: "${address}"`);
    
    let coords = null;
    
    // Verifier si la salle a déjà de BONNES coordonnees
    if (room.location?.lat && room.location?.lng) {
      // Verifier si ce ne sont pas les coordonnées par defaut d'Alger
      if (!(room.location.lat === 36.75 && room.location.lng === 3.06)) {
        coords = {
          lat: room.location.lat,
          lng: room.location.lng
        };
        console.log(`Utilisation coordonnées existantes: ${coords.lat}, ${coords.lng}`);
      }
    }
    
    //Sinon, obtenir les coordonnées exactes
    if (!coords && address.trim() !== '') {
      coords = await getExactCoordinatesForAddress(address, room._id);
      
      // Mettre à jour les coordonnees dans la salle
      if (coords) {
        if (!room.location) room.location = {};
        room.location.lat = coords.lat;
        room.location.lng = coords.lng;
        console.log(`Coordonnées mises à jour: ${coords.lat}, ${coords.lng}`);
      }
    }
    
    //Ajouter le marqueur si on a des coordonnees
    if (coords) {
      const detectedCity = detectCityFromAddress(address);
      const marker = L.marker([coords.lat, coords.lng]);
      
      // Afficher la premiere image ou une image par défaut
      const mainImage = room.mainImage || (room.images && room.images.length > 0 ? room.images[0] : null);
      const imageUrl = mainImage || 'https://via.placeholder.com/150x100?text=Salle';
      
      
      let popupContent = `
        <div style="min-width: 250px; max-width: 350px;">
          <div class="d-flex align-items-start">
            <div style="width: 80px; margin-right: 10px;">
              <img src="${imageUrl}" 
                   style="width: 100%; height: 80px; object-fit: cover; border-radius: 5px;"
                   alt="${room.title}">
              ${room.images && room.images.length > 1 ? 
                `<small class="text-muted d-block text-center mt-1">
                  <i class="fas fa-images fa-xs"></i> ${room.images.length} photos
                </small>` : ''}
            </div>
            <div style="flex: 1;">
              <strong class="d-block mb-1">${room.title}</strong>
              <div class="text-success mb-1">${room.price} DA/heure</div>
              <div class="mb-1">
                <i class="fas fa-users text-primary fa-xs"></i> ${room.capacity} pers.
                ${room.averageRating > 0 ? 
                  `<span class="ms-2">
                    <i class="fas fa-star text-warning fa-xs"></i> ${room.averageRating.toFixed(1)}
                  </span>` : ''}
              </div>
            </div>
          </div>
      `;
      
      if (detectedCity) {
        popupContent += `<div class="text-primary mb-1">
          <i class="fas fa-map-marker-alt fa-xs"></i> ${detectedCity}
        </div>`;
      }
      
      popupContent += `<small class="text-muted">${address || 'Adresse non spécifiée'}</small>`;
      popupContent += `<br><button class="btn btn-sm btn-primary mt-2 w-100" onclick="window.location.href='auth.html'">
        <i class="fas fa-calendar-plus me-1"></i> Réserver
      </button>`;
      popupContent += `</div>`;
      
      marker.bindPopup(popupContent);
      markers.push(marker);
      markerCluster.addLayer(marker);
      
      console.log(`Marqueur ajouté: ${room.title} à ${coords.lat}, ${coords.lng}`);
    } else {
      console.warn(`Pas de coordonnées pour: ${room.title}`);
    }
  }
  
  
  if (markers.length > 0) {
    const bounds = L.latLngBounds(markers.map(m => m.getLatLng()));
    map.fitBounds(bounds.pad(0.1));
  } else {
    
    map.setView([28.0, 2.0], 5);
  }
}


async function getExactCoordinatesForAddress(address, roomId = 'default') {
  if (!address || address.trim() === '') {
    return { lat: 36.75, lng: 3.06 }; 
  }
  
  console.log(`Recherche coordonnées pour: "${address}"`);
  
  
  const detectedCity = detectExactCityFromAddress(address);
  console.log(`Ville détectée: ${detectedCity || 'Non détectée'}`);
  
  
  if (detectedCity) {
    const cityKey = detectedCity.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (ALGERIAN_CITIES_COORDS[cityKey]) {
      const coords = {
        lat: ALGERIAN_CITIES_COORDS[cityKey].lat,
        lng: ALGERIAN_CITIES_COORDS[cityKey].lng,
        source: 'city_lookup'
      };
      console.log(`Coordonnées ville: ${detectedCity} -> ${coords.lat}, ${coords.lng}`);
      return coords;
    }
  }
  
  
  try {
    const cleanAddress = normalizeAddressForGeocoding(address);
    const cacheKey = `geocode_${cleanAddress}`;
    const cached = localStorage.getItem(cacheKey);
    
    if (cached) {
      console.log(`Utilisation cache pour "${cleanAddress}"`);
      const parsed = JSON.parse(cached);
      parsed.source = 'cache';
      return parsed;
    }
    
    console.log(`Géocodage API pour: "${cleanAddress}"`);
    
    
    let searchQuery = cleanAddress;
    if (detectedCity) {
      searchQuery = detectedCity + ', Algérie';
    } else if (!cleanAddress.includes('algérie') && !cleanAddress.includes('algerie')) {
      searchQuery = cleanAddress + ', Algérie';
    }
    
    console.log(`Requête géocodage: "${searchQuery}"`);
    
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchQuery)}&format=json&limit=1&countrycodes=DZ&accept-language=fr`,
      {
        headers: {
          'User-Agent': 'RoomBookingApp/1.0',
          'Accept': 'application/json'
        }
      }
    );
    
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.length > 0) {
        const coords = {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon),
          display_name: data[0].display_name,
          source: 'api'
        };
        
        console.log(`Géocodé avec succès: "${address}" -> ${coords.display_name} (${coords.lat}, ${coords.lng})`);
        
        
        localStorage.setItem(cacheKey, JSON.stringify(coords));
        setTimeout(() => localStorage.removeItem(cacheKey), 24 * 60 * 60 * 1000);
        
        return coords;
      }
    }
    
    console.warn(`Géocodage échoué pour: "${address}"`);
  } catch (error) {
    console.error(`Erreur géocodage:`, error);
  }
  
  
  if (detectedCity) {
    return { lat: 36.75, lng: 3.06, source: 'fallback_city' };
  }
  
  
  console.log(`Utilisation coordonnées par défaut pour: "${address}"`);
  return { lat: 36.75, lng: 3.06, source: 'default' };
}


function detectExactCityFromAddress(address) {
  if (!address) return null;
  
  const normalized = address.toLowerCase()
    .replace(/algérie/gi, '')
    .replace(/algerie/gi, '')
    .replace(/alger/gi, '')  
    .trim();
  
  console.log(`Détection ville pour: "${address}" -> normalisé: "${normalized}"`);
  
  
  const cities = {
    'bechar': ['bechar', 'béchar'],
    'alger': ['alger'],
    'oran': ['oran', 'وهران'],
    'constantine': ['constantine'],
    'annaba': ['annaba', 'عنابة'],
    'batna': ['batna'],
    'blida': ['blida', ],
    'setif': ['setif','sétif'],
    'sidi bel abbes': ['sidi bel abbes','sidi bel abbès'],
    'biskra': ['biskra'],
    'tebessa': ['tebessa','tébessa'],
    'tiaret': ['tiaret'],
    'bejaia': ['bejaia','bejaïa', 'béjaïa'],
    'tlemcen': ['tlemcen'],
    'skikda': ['skikda'],
    'souk ahras': ['souk ahras'],
    'msila': ['msila','m\'sila'],
    'el oued': ['el oued'],
    'laghouat': ['laghouat'],
    'ouargla': ['ouargla'],
    'mostaganem': ['mostaganem'],
    'medea': ['medea','médéa'],
    'tizi ouzou': ['tizi ouzou'],
    'jijel': ['jijel', 'جيجل'],
    'saida': ['saida','saïda'],
    'guelma': ['guelma']
  };
  
  const words = normalized.split(/[,\s]+/).filter(word => word.length > 2);
  
  for (const word of words) {
    for (const [city, patterns] of Object.entries(cities)) {
      for (const pattern of patterns) {
        if (word === pattern) {
          console.log(`Détection exacte: "${word}" -> ${city}`);
          return city;
        }
      }
    }
  }
  

  for (const [city, patterns] of Object.entries(cities)) {
    for (const pattern of patterns) {
      if (normalized.includes(pattern)) {
        console.log(`Détection partielle: "${pattern}" dans "${normalized}" -> ${city}`);
        return city;
      }
    }
  }
  
  console.log(`Aucune ville détectée pour: "${address}"`);
  return null;
}


function detectCityFromAddress(address) {
  const cityKey = detectExactCityFromAddress(address);
  if (cityKey && ALGERIAN_CITIES_COORDS[cityKey]) {
    return ALGERIAN_CITIES_COORDS[cityKey].name;
  }
  return null;
}

function normalizeAddressForGeocoding(address) {
  if (!address) return '';
  
  return address
    .toLowerCase()
    .trim()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s,.-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function clearMarkers() {
  if (markerCluster) {
    markerCluster.clearLayers();
  }
  markers = [];
}


function showRoomGallery(roomId) {
  const room = allRooms.find(r => r._id === roomId);
  if (!room) {
    alert("Salle non trouvée");
    return;
  }
  
  if (!room.images || room.images.length === 0) {
    alert("Cette salle n'a pas d'images");
    return;
  }
  
  const galleryHtml = `
    <div class="modal fade" id="galleryModal-${roomId}" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              <i class="fas fa-images me-2"></i>${room.title} - Galerie
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div id="carousel-${roomId}" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                ${room.images.map((img, index) => `
                  <div class="carousel-item ${index === 0 ? 'active' : ''}">
                    <div class="text-center">
                      <img src="${img}" 
                           class="img-fluid rounded" 
                           style="max-height: 60vh; object-fit: contain;"
                           alt="Image ${index + 1} de ${room.title}">
                    </div>
                    <div class="text-center mt-3">
                      <span class="badge bg-dark">Image ${index + 1}/${room.images.length}</span>
                    </div>
                  </div>
                `).join('')}
              </div>
              
              ${room.images.length > 1 ? `
                <button class="carousel-control-prev" type="button" data-bs-target="#carousel-${roomId}" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon bg-dark rounded-circle p-2"></span>
                  <span class="visually-hidden">Précédent</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carousel-${roomId}" data-bs-slide="next">
                  <span class="carousel-control-next-icon bg-dark rounded-circle p-2"></span>
                  <span class="visually-hidden">Suivant</span>
                </button>
              ` : ''}
            </div>
            
            <div class="mt-4">
              <div class="row" id="thumbnails-${roomId}">
                ${room.images.map((img, index) => `
                  <div class="col-2 mb-2">
                    <img src="${img}" 
                         class="img-thumbnail ${index === 0 ? 'border-primary' : ''}" 
                         style="cursor: pointer; height: 60px; object-fit: cover;"
                         onclick="goToSlide('${roomId}', ${index})"
                         alt="Miniature ${index + 1}">
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
              <i class="fas fa-times me-1"></i>Fermer
            </button>
            <a href="auth.html" class="btn btn-primary">
              <i class="fas fa-calendar-plus me-1"></i>Réserver cette salle
            </a>
          </div>
        </div>
      </div>
    </div>
  `;
  
 
  const oldModal = document.getElementById(`galleryModal-${roomId}`);
  if (oldModal) oldModal.remove();
  
 
  document.body.insertAdjacentHTML('beforeend', galleryHtml);
  
 
  const modal = new bootstrap.Modal(document.getElementById(`galleryModal-${roomId}`));
  modal.show();
  
  
  const carousel = document.getElementById(`carousel-${roomId}`);
  if (carousel) {
    carousel.addEventListener('slide.bs.carousel', function (event) {
      const thumbnails = document.querySelectorAll(`#thumbnails-${roomId} .img-thumbnail`);
      thumbnails.forEach((thumb, index) => {
        thumb.classList.toggle('border-primary', index === event.to);
      });
    });
  }
  
  document.getElementById(`galleryModal-${roomId}`).addEventListener('hidden.bs.modal', function() {
    setTimeout(() => {
      if (document.body.contains(this)) {
        this.remove();
      }
    }, 300);
  });
}


function renderRoomsSlider(rooms) {
  const slider = document.getElementById('roomSlider');
  slider.innerHTML = ''; 

  rooms.forEach(room => {
    const detectedCity = detectCityFromAddress(room.location?.address);

    
    const mainImage = room.mainImage || (room.images && room.images[0]) || 
                      'https://via.placeholder.com/300x200?text=Salle+de+réunion';

   
    const amenitiesBadges = room.amenities && room.amenities.length > 0 ? 
      room.amenities.map(amenity => {
        const icons = {
          'wifi': 'fa-wifi',
          'projector': 'fa-video',
          'whiteboard': 'fa-chalkboard',
          'air-conditioning': 'fa-snowflake',
          'coffee': 'fa-coffee',
          'parking': 'fa-parking'
        };
        return `<span class="badge bg-light text-dark me-1" title="${amenity}">
                  <i class="fas ${icons[amenity] || 'fa-check'} fa-xs me-1"></i>${amenity}
                </span>`;
      }).join('') : '';

    
    const cardHtml = `
      <div class="room-card shadow-sm">
        <img src="${mainImage}" class="room-image rounded-top" alt="${room.title}" onclick="showRoomGallery('${room._id}')">
        <div class="p-3">
          <h5 class="mb-1">${room.title}</h5>
          <div class="text-success mb-2">${room.price} DA/h</div>
          <div class="mb-2">
            <i class="fas fa-users me-1"></i>${room.capacity} pers.
            ${room.averageRating > 0 ? `<span class="ms-2">
              <i class="fas fa-star text-warning fa-xs"></i> ${room.averageRating.toFixed(1)}
            </span>` : ''}
          </div>
          ${detectedCity ? `<div class="text-primary mb-2">
            <i class="fas fa-map-marker-alt fa-xs"></i> ${detectedCity}
          </div>` : ''}
          <div class="mb-2">
            ${amenitiesBadges}
          </div>
          <div class="d-flex justify-content-between mt-3">
            <button class="btn btn-sm btn-outline-secondary" onclick="showRoomGallery('${room._id}')">
              <i class="fas fa-images me-1"></i>Voir images
            </button>
            <a href="auth.html" class="btn btn-sm btn-primary">
              <i class="fas fa-calendar-plus me-1"></i>Réserver
            </a>
          </div>
        </div>
      </div>
    `;

    slider.insertAdjacentHTML('beforeend', cardHtml);
  });
}



let currentOffset = 0;
function scrollSlider(direction) {
  const slider = document.getElementById('roomSlider');
  const cardWidth = slider.children[0].offsetWidth + 15; // largeur + gap
  const wrapper = document.querySelector('.room-slider-wrapper');
  const maxOffset = slider.scrollWidth - wrapper.offsetWidth;

  currentOffset += direction * cardWidth * 2; // defiler 2 cartes à la fois
  if (currentOffset < 0) currentOffset = 0;
  if (currentOffset > maxOffset) currentOffset = maxOffset;

  slider.style.transform = `translateX(-${currentOffset}px)`;
}



// Fonction pour aller à un slide specifique
function goToSlide(roomId, slideIndex) {
  const carousel = document.getElementById(`carousel-${roomId}`);
  if (!carousel) return;
  
  const bsCarousel = bootstrap.Carousel.getInstance(carousel);
  if (bsCarousel) {
    bsCarousel.to(slideIndex);
  }
}


function showRoomReviews(roomId) {
  
  window.location.href = 'auth.html';
  
}

function applyFilters() {
  console.log("APPLICATION FILTRES ");
  
  const locationSearch = document.getElementById('location-search')?.value.toLowerCase() || '';
  const minPrice = parseFloat(document.getElementById('min-price')?.value) || 0;
  const maxPrice = parseFloat(document.getElementById('max-price')?.value) || Infinity;
  const minCapacity = parseInt(document.getElementById('min-capacity')?.value) || 0;
  
  const amenities = [];
  if (document.getElementById('filter-wifi')?.checked) amenities.push('wifi');
  if (document.getElementById('filter-projector')?.checked) amenities.push('projector');
  if (document.getElementById('filter-whiteboard')?.checked) amenities.push('whiteboard');
  if (document.getElementById('filter-air-conditioning')?.checked) amenities.push('air-conditioning');
  if (document.getElementById('filter-coffee')?.checked) amenities.push('coffee');
  if (document.getElementById('filter-parking')?.checked) amenities.push('parking');
  
  filterAndDisplayRooms({
    location: locationSearch,
    minPrice,
    maxPrice,
    minCapacity,
    amenities
  });
}

function filterAndDisplayRooms(filters = {}) {
  let filteredRooms = allRooms;
  
  filteredRooms = filteredRooms.filter(room => {
    if (filters.location && filters.location.trim() !== '') {
      const searchTerm = filters.location.toLowerCase().trim();
      const address = room.location?.address?.toLowerCase() || '';
      const city = detectCityFromAddress(room.location?.address)?.toLowerCase() || '';
      const title = room.title?.toLowerCase() || '';
      const description = room.description?.toLowerCase() || '';
      
      if (!address.includes(searchTerm) && 
          !city.includes(searchTerm) && 
          !title.includes(searchTerm) && 
          !description.includes(searchTerm)) {
        return false;
      }
    }
    
    if (room.price < filters.minPrice || room.price > filters.maxPrice) {
      return false;
    }
    
    if (room.capacity < filters.minCapacity) {
      return false;
    }
    
    if (filters.amenities && filters.amenities.length > 0) {
      if (!room.amenities || !Array.isArray(room.amenities)) {
        return false;
      }
      
      const hasAllAmenities = filters.amenities.every(amenity => 
        room.amenities.includes(amenity)
      );
      
      if (!hasAllAmenities) {
        return false;
      }
    }
    
    return true;
  });
  
  console.log("Salles filtrées:", filteredRooms.length);
  
  if (filteredRooms.length === 0) {
    document.getElementById('rooms-container').innerHTML = `
      <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i>
        Aucune salle ne correspond à vos critères de recherche.
        <button class="btn btn-sm btn-outline-primary ms-2" onclick="resetFilters()">
          Réinitialiser les filtres
        </button>
      </div>
    `;
  } else {
    renderRoomsSlider(filteredRooms);
  }
  
  updateMapWithFilteredRooms(filteredRooms);
}

function updateMapWithFilteredRooms(rooms) {
  addMarkersWithGeocoding(rooms);
}

function resetFilters() {
  document.getElementById('location-search').value = '';
  document.getElementById('min-price').value = '';
  document.getElementById('max-price').value = '';
  document.getElementById('min-capacity').value = '';
  
  document.getElementById('filter-wifi').checked = false;
  document.getElementById('filter-projector').checked = false;
  document.getElementById('filter-whiteboard').checked = false;
  document.getElementById('filter-air-conditioning').checked = false;
  document.getElementById('filter-coffee').checked = false;
  document.getElementById('filter-parking').checked = false;
  
  renderRoomsSlider(allRooms);
  updateMapWithFilteredRooms(allRooms);
}

function addResetButton() {
  const filterCard = document.querySelector('.card-body');
  if (filterCard && !document.getElementById('reset-filters-btn')) {
    const resetButton = document.createElement('button');
    resetButton.id = 'reset-filters-btn';
    resetButton.className = 'btn btn-secondary w-100 mt-2';
    resetButton.innerHTML = '<i class="fas fa-redo me-1"></i>Réinitialiser les filtres';
    resetButton.onclick = resetFilters;
    filterCard.appendChild(resetButton);
  }
}

function addAmenityFilters() {
  const amenitiesSection = document.querySelector('.mb-3:has(#filter-whiteboard)');
  if (amenitiesSection) {
    const extraAmenities = `
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="air-conditioning" id="filter-air-conditioning">
        <label class="form-check-label" for="filter-air-conditioning">
          <i class="fas fa-snowflake text-primary me-1"></i>Climatisation
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="coffee" id="filter-coffee">
        <label class="form-check-label" for="filter-coffee">
          <i class="fas fa-coffee text-primary me-1"></i>Café/Thé
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="parking" id="filter-parking">
        <label class="form-check-label" for="filter-parking">
          <i class="fas fa-parking text-primary me-1"></i>Parking
        </label>
      </div>
    `;
    amenitiesSection.insertAdjacentHTML('beforeend', extraAmenities);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  console.log("Chargement de la page d'accueil...");
  loadPublicRooms();
  addResetButton();
  addAmenityFilters();
  
  const mapSection = document.querySelector('#map').parentElement;
  const refreshBtn = document.createElement('button');
  refreshBtn.className = 'btn btn-sm btn-outline-primary mb-2';
  refreshBtn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>Actualiser la carte';
  refreshBtn.onclick = function() {
    loadPublicRooms();
    showSuccess('Carte actualisée !');
  };
  mapSection.insertBefore(refreshBtn, mapSection.firstChild);
});


function showSuccess(message) {
  const alert = document.createElement('div');
  alert.className = 'alert alert-success alert-dismissible fade show position-fixed';
  alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
  alert.innerHTML = `
    <i class="fas fa-check-circle me-2"></i>${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  `;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 3000);
}

function filterByKeyword(keyword) {
    console.log(`Filtrage par mot-clé: ${keyword}`);
    
    let filteredRooms = allRooms.filter(room => {
        
        const searchText = (room.title + ' ' + room.description + ' ' + (room.amenities ? room.amenities.join(' ') : '')).toLowerCase();
        
        
        const keywordMap = {
            'réunion': ['réunion', 'reunion', 'meeting', 'réunions', 'réunions d\'affaires', 'salle de réunion'],
            'fêtes': ['fêtes', 'fete', 'fetes', 'party', 'anniversaire', 'célébration', 'événement'],
            'coworking': ['coworking', 'cowork', 'espace de travail', 'open space', 'bureau partagé']
        };
        
        
        const searchTerms = keywordMap[keyword] || [keyword];
        
        
        return searchTerms.some(term => searchText.includes(term.toLowerCase()));
    });
    
    console.log(`Salles trouvées pour "${keyword}":`, filteredRooms.length);
    
    
    if (filteredRooms.length === 0) {
        
        const slider = document.getElementById('roomSlider');
        slider.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Aucune salle trouvée pour "${keyword}"</h4>
                <button class="btn btn-outline-primary mt-2" onclick="resetKeywordFilters()">
                    Voir toutes les salles
                </button>
            </div>
        `;
    } else {
        renderRoomsSlider(filteredRooms);
    }
    
    
    addMarkersWithGeocoding(filteredRooms);
    
    
    highlightActiveKeywordButton(keyword);
}


function resetKeywordFilters() {
    console.log("Réinitialisation des filtres par mot-clé");
    
    
    if (document.getElementById('location-search')) {
        document.getElementById('location-search').value = '';
    }
    if (document.getElementById('min-price')) {
        document.getElementById('min-price').value = '';
    }
    if (document.getElementById('max-price')) {
        document.getElementById('max-price').value = '';
    }
    if (document.getElementById('min-capacity')) {
        document.getElementById('min-capacity').value = '';
    }
    
    
    document.querySelectorAll('.btn-outline-primary').forEach(btn => {
        btn.classList.remove('active');
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-primary');
    });
    
   
    renderRoomsSlider(allRooms);
    addMarkersWithGeocoding(allRooms);
}


function highlightActiveKeywordButton(keyword) {
    
    document.querySelectorAll('.btn-outline-primary').forEach(btn => {
        btn.classList.remove('active');
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-primary');
    });
    
   
    const buttons = document.querySelectorAll('.btn-outline-primary');
    buttons.forEach(btn => {
        if (btn.onclick && btn.onclick.toString().includes(`'${keyword}'`)) {
            btn.classList.remove('btn-outline-primary');
            btn.classList.add('btn-primary', 'active');
        }
    });
}


document.addEventListener('DOMContentLoaded', function() {
    
    
    
    const style = document.createElement('style');
    style.textContent = `
        .btn-outline-primary.active,
        .btn-primary.active {
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.5);
        }
    `;
    document.head.appendChild(style);
});


window.filterByKeyword = filterByKeyword;
window.resetKeywordFilters = resetKeywordFilters;

window.applyFilters = applyFilters;
window.resetFilters = resetFilters;
window.showRoomGallery = showRoomGallery;
window.showRoomReviews = showRoomReviews;
window.goToSlide = goToSlide;
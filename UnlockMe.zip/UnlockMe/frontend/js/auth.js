
const API = "http://localhost:3000/api";


window.login = async function() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const remember = document.getElementById("remember")?.checked || false;
  
  if (!email || !password) {
    showAlert("Veuillez remplir tous les champs", "error");
    return;
  }
  
 
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showAlert("Veuillez entrer une adresse email valide", "error");
    return;
  }
  
  try {
    
    showLoading('login-btn', true);
    
    const response = await fetch(`${API}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, password })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || "Erreur de connexion");
    }
    
   
    localStorage.setItem("token", data.token);
    localStorage.setItem("role", data.role);
    localStorage.setItem("userId", data._id);
    localStorage.setItem("userName", data.name);
    localStorage.setItem("userEmail", data.email);
    
    
    if (remember) {
      sessionStorage.setItem("userRemembered", "true");
    }
    
   
    showAlert(`Bienvenue ${data.name} ! Connexion réussie.`, "success");
    
    
    setTimeout(() => {
      
      switch(data.role) {
        case "client":
          window.location.href = "client.html";
          break;
        case "owner":
          window.location.href = "owner.html";
          break;
        case "admin":
          window.location.href = "admin.html";
          break;
        default:
          showAlert("Rôle non reconnu", "error");
      }
    }, 1500);
    
  } catch (error) {
    console.error("Erreur login:", error);
    showAlert("Erreur: " + error.message, "error");
  } finally {
    showLoading('login-btn', false);
  }
};


window.register = async function() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("emailR").value.trim();
  const password = document.getElementById("passwordR").value;
  const role = document.getElementById("role").value;
  const terms = document.getElementById("terms");
  
 
  if (!name || !email || !password) {
    showAlert("Veuillez remplir tous les champs", "error");
    return;
  }
  
  if (name.length < 2) {
    showAlert("Le nom doit contenir au moins 2 caractères", "error");
    return;
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showAlert("Veuillez entrer une adresse email valide", "error");
    return;
  }
  
  if (password.length < 2) {
    showAlert("Le mot de passe doit contenir au moins 6 caractères", "error");
    return;
  }
  
  
  
  try {
    
    showLoading('register-btn', true);
    
    const response = await fetch(`${API}/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ name, email, password, role })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || "Erreur d'inscription");
    }
    
   
    showAlert(`Félicitations ${name} ! Votre compte a été créé avec succès.`, "success");
    
    
    setTimeout(() => {
      document.getElementById("email").value = email;
      document.getElementById("password").value = password;
      showLogin();
      showAlert("Vous pouvez maintenant vous connecter", "success");
    }, 2000);
    
  } catch (error) {
    console.error("Erreur register:", error);
    showAlert("Erreur: " + error.message, "error");
  } finally {
    showLoading('register-btn', false);
  }
};

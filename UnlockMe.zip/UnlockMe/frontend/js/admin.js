const API = "http://localhost:3000/api";
const token = localStorage.getItem("token");
const userRole = localStorage.getItem("role");

if (!token || userRole !== "admin") {
  alert("Accès réservé aux administrateurs");
  window.location.href = "auth.html";
}


let allBookings = [];
let allRooms = [];
let allUsers = [];
let allReviews = [];
let bookingChart = null;


document.addEventListener('DOMContentLoaded', function() {
  console.log(" Admin dashboard initialisé");
  console.log("Token:", token ? "Présent" : "Absent");
  console.log("Rôle:", userRole);
  
 
  
  
  document.getElementById('user-info').textContent = `Connecte en tant que: ${userRole || "Admin"}`;
  
  setupEventListeners();
  
  loadDashboardData();
});



function setupEventListeners() {
  console.log("Configuration des événements...");
  
  
  document.getElementById('dashboard-link').addEventListener('click', () => showSection('dashboard'));
  document.getElementById('bookings-link').addEventListener('click', () => showSection('bookings'));
  document.getElementById('rooms-link').addEventListener('click', () => showSection('rooms'));
  document.getElementById('users-link').addEventListener('click', () => showSection('users'));
  document.getElementById('reviews-link').addEventListener('click', () => showSection('reviews'));
  document.getElementById('logout-link').addEventListener('click', logout);
  
  
  document.getElementById('refresh-btn').addEventListener('click', refreshData);
  document.getElementById('export-btn').addEventListener('click', exportBookings);
  
  document.getElementById('save-booking-btn').addEventListener('click', saveBookingChanges);
  
  // Recherches
  document.getElementById('room-search').addEventListener('input', searchRooms);
  document.getElementById('user-search').addEventListener('input', searchUsers);
  document.getElementById('booking-search').addEventListener('input', searchBookings);
  document.getElementById('review-filter').addEventListener('change', (e) => filterReviews(e.target.value));
  
  console.log(" Événements configurés");
}


function showSection(section) {
  console.log(`Chargement section: ${section}`);
  
  
  document.querySelectorAll('.section-content').forEach(el => {
    el.classList.add('d-none');
  });
  
  
  document.querySelectorAll('.sidebar .nav-link').forEach(el => {
    el.classList.remove('active');
  });
  
  
  const sectionEl = document.getElementById(`${section}-section`);
  if (sectionEl) {
    sectionEl.classList.remove('d-none');
  }
  
  
  const activeLink = document.getElementById(`${section}-link`);
  if (activeLink) {
    activeLink.classList.add('active');
  }
  
  
  const titles = {
    dashboard: 'Dashboard',
    bookings: 'Gestion des réservations',
    rooms: 'Gestion des salles',
    users: 'Gestion des utilisateurs',
    reviews: 'Modération des avis'
  };
  document.getElementById('section-title').textContent = titles[section] || 'Dashboard';
  
  switch(section) {
    case 'dashboard':
      loadDashboardData();
      break;
    case 'bookings':
      loadBookings();
      break;
    case 'rooms':
      loadRooms();
      break;
    case 'users':
      loadUsers();
      break;
    case 'reviews':
      loadReviews();
      break;
  }
}


async function loadDashboardData() {
  console.log("Chargement dashboard...");
  
  try {
    
    document.getElementById('total-bookings').textContent = "...";
    document.getElementById('total-rooms').textContent = "...";
    document.getElementById('total-users').textContent = "...";
    document.getElementById('total-revenue').textContent = "... DA";
    
    const [bookingsRes, roomsRes, usersRes, reviewsRes] = await Promise.all([
      fetch(`${API}/bookings`, {
        headers: { "Authorization": `Bearer ${token}` }
      }).catch(err => {
        console.error("Erreur réservations:", err);
        return { ok: false };
      }),
      fetch(`${API}/rooms`).catch(err => {
        console.error("Erreur salles:", err);
        return { ok: false };
      }),
      fetch(`${API}/auth/users`, {
        headers: { "Authorization": `Bearer ${token}` }
      }).catch(err => {
        console.error(" Erreur utilisateurs:", err);
        return { ok: false };
      }),
      fetch(`${API}/reviews/admin`, {
        headers: { "Authorization": `Bearer ${token}` }
      }).catch(err => {
        console.error(" Erreur avis:", err);
        return { ok: false };
      })
    ]);

   
    if (bookingsRes.ok) {
      allBookings = await bookingsRes.json();
      console.log(` ${allBookings.length} réservations chargées`);
      
    } else {
      console.error("Echec chargement réservations");
      document.getElementById('total-bookings').textContent = "Err";
    }

    
    if (roomsRes.ok) {
      allRooms = await roomsRes.json();
      console.log(` ${allRooms.length} salles chargées`);
      document.getElementById('total-rooms').textContent = allRooms.length;
    } else {
      console.error(" Echec chargement salles");
      document.getElementById('total-rooms').textContent = "Err";
    }
    if (allBookings.length && allRooms.length) {
  updateBookingStats(allBookings);
}

    
    if (usersRes.ok) {
      allUsers = await usersRes.json();
      console.log(` ${allUsers.length} utilisateurs chargés`);
      document.getElementById('total-users').textContent = allUsers.length;
    } else {
      console.warn(" Route /auth/users non disponible");
      document.getElementById('total-users').textContent = "N/A";
    }

   
    if (reviewsRes.ok) {
      const data = await reviewsRes.json();
      console.log(" Données avis:", data);
      
      if (data && data.reviews) {
        allReviews = data.reviews;
      } else if (Array.isArray(data)) {
        allReviews = data;
      } else {
        allReviews = [];
      }
      
      console.log(`${allReviews.length} avis chargés`);
      updateReviewStats(allReviews);
      updateReviewsBadge(allReviews);
    } else {
      console.warn(" Avis non chargés");
      allReviews = [];
    }

  } catch (error) {
    console.error(" Erreur chargement dashboard:", error);
    showError("Erreur lors du chargement des données: " + error.message);
  }
}


function updateReviewsBadge(reviews) {
  const reviewsLink = document.getElementById('reviews-link');
  if (!reviewsLink) return;
  
  
  const oldBadge = reviewsLink.querySelector('.badge');
  if (oldBadge) oldBadge.remove();
  
  const pendingReviews = reviews.filter(r => r.status === 'pending').length;
  if (pendingReviews > 0) {
    const badge = document.createElement('span');
    badge.className = 'badge bg-danger ms-1';
    badge.textContent = pendingReviews;
    reviewsLink.appendChild(badge);
  }
}


function updateBookingStats(bookings) {
  document.getElementById('total-bookings').textContent = bookings.length;
  
  
  const revenue = bookings
    .filter(b => b.status === 'confirmed')
    .reduce((sum, b) => {
      const room = allRooms.find(r => r._id === b.room?._id || r._id === b.room);
      if (room?.price) {
        const start = new Date(b.startDate);
        const end = new Date(b.endDate);
        const hours = (end - start) / (1000 * 60 * 60);
        return sum + (room.price * hours);
      }
      return sum;
    }, 0);
  
  document.getElementById('total-revenue').textContent = `${revenue.toFixed(2)} DA`;
  
 
  showRecentActivity(bookings);
  
  
  showBookingStatusChart(bookings);
}

function updateReviewStats(reviews) {
  const approved = reviews.filter(r => r.status === 'approved').length;
  const pending = reviews.filter(r => r.status === 'pending').length;

  const elApproved = document.getElementById('approved-reviews');
  const elPending = document.getElementById('pending-reviews');

  if (elApproved) elApproved.textContent = approved;
  if (elPending) elPending.textContent = pending;
}


function showRecentActivity(bookings) {
  const container = document.getElementById('recent-activity');
  const recent = bookings
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);
  
  if (recent.length === 0) {
    container.innerHTML = '<p class="text-muted">Aucune activité récente</p>';
    return;
  }
  
  const html = recent.map(booking => {
    const room = allRooms.find(r => r._id === booking.room?._id || r._id === booking.room);
    return `
    <div class="d-flex mb-3">
      <div class="flex-shrink-0">
        <i class="fas fa-calendar-alt bg-light p-2 rounded"></i>
      </div>
      <div class="flex-grow-1 ms-3">
        <p class="mb-1">
          <strong>${booking.user?.name || booking.user?.email || 'Utilisateur'}</strong>
          a réservé <strong>${room?.title || 'une salle'}</strong>
        </p>
        <small class="text-muted">${new Date(booking.createdAt).toLocaleString('fr-FR')}</small>
        <span class="badge ${getStatusBadgeClass(booking.status)} ms-2">${getStatusText(booking.status)}</span>
      </div>
    </div>
    `;
  }).join('');
  
  container.innerHTML = html;
}


function showBookingStatusChart(bookings) {
  const statusCounts = {
    pending: bookings.filter(b => b.status === 'pending').length,
    confirmed: bookings.filter(b => b.status === 'confirmed').length,
    cancelled: bookings.filter(b => b.status === 'cancelled').length
  };
  
  const ctx = document.getElementById('statusChart');
  if (!ctx) return;
  
  
  if (bookingChart) {
    bookingChart.destroy();
  }
  
  try {
    bookingChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['En attente', 'Confirmées', 'Annulées'],
        datasets: [{
          data: [statusCounts.pending, statusCounts.confirmed, statusCounts.cancelled],
          backgroundColor: ['#ffc107', '#198754', '#dc3545'],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  } catch (error) {
    console.error("Erreur création graphique:", error);
  }
}


async function loadBookings() {
  try {
    const res = await fetch(`${API}/bookings`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (res.ok) {
      allBookings = await res.json();
      renderBookingsTable(allBookings);
    } else {
      throw new Error(`Erreur ${res.status}`);
    }
  } catch (error) {
    console.error(" Erreur chargement réservations:", error);
    document.getElementById('bookings-table').innerHTML = `
      <tr><td colspan="8" class="text-center text-danger">
        Erreur: ${error.message}
      </td></tr>
    `;
  }
}


function renderBookingsTable(bookings) {
  const html = bookings.map(booking => {
    const room = allRooms.find(r => r._id === booking.room?._id || r._id === booking.room);
    const start = new Date(booking.startDate);
    const end = new Date(booking.endDate);
    const hours = (end - start) / (1000 * 60 * 60);
    const totalPrice = room?.price ? room.price * hours : 0;
    
    return `
    <tr>
      <td><small class="text-muted">${booking._id?.substring(0, 8) || 'N/A'}...</small></td>
      <td>
        ${booking.user?.name || 'N/A'}<br>
        <small class="text-muted">${booking.user?.email || ''}</small>
      </td>
      <td>${room?.title || 'Salle inconnue'}</td>
      <td>
        <small>${start.toLocaleDateString('fr-FR')}</small><br>
        <small class="text-muted">${start.toLocaleTimeString('fr-FR', {hour: '2-digit', minute:'2-digit'})} - ${end.toLocaleTimeString('fr-FR', {hour: '2-digit', minute:'2-digit'})}</small>
      </td>
      <td>
        <span class="badge ${getStatusBadgeClass(booking.status)}">
          ${getStatusText(booking.status)}
        </span>
      </td>
      <td>${room?.price ? `${room.price} DA/h` : '0 DA'}</td>
      <td>${totalPrice.toFixed(2)} DA</td>
      <td>
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-primary" onclick="window.editBooking('${booking._id}')" title="Modifier">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn btn-outline-danger" onclick="window.deleteBooking('${booking._id}')" title="Supprimer">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </td>
    </tr>
    `;
  }).join('');
  
  document.getElementById('bookings-table').innerHTML = html || `
    <tr><td colspan="8" class="text-center text-muted">Aucune réservation</td></tr>
  `;
}


function searchBookings() {
  const term = document.getElementById('booking-search').value.toLowerCase();
  const filtered = allBookings.filter(booking => 
    (booking.user?.name || '').toLowerCase().includes(term) ||
    (booking.user?.email || '').toLowerCase().includes(term) ||
    (booking.room?.title || '').toLowerCase().includes(term) ||
    booking.status.toLowerCase().includes(term)
  );
  renderBookingsTable(filtered);
}


async function loadRooms() {
  try {
    const res = await fetch(`${API}/rooms`);
    
    if (res.ok) {
      allRooms = await res.json();
      renderRoomsTable(allRooms);
    } else {
      throw new Error(`Erreur ${res.status}`);
    }
  } catch (error) {
    console.error("Erreur chargement salles:", error);
    document.getElementById('rooms-table').innerHTML = `
      <tr><td colspan="8" class="text-center text-danger">Erreur: ${error.message}</td></tr>
    `;
  }
}


function renderRoomsTable(rooms) {
  const html = rooms.map(room => `
    <tr>
      <td>
        <strong>${room.title}</strong><br>
        <small class="text-muted">${room.location?.address || 'Adresse non spécifiée'}</small>
      </td>
      <td>${room.description || 'Pas de description'}</td>
      <td><span class="badge bg-info">${room.capacity} pers.</span></td>
      <td><strong>${room.price || 0} DA</strong><br><small>par heure</small></td>
      <td>
        <i class="fas fa-star text-warning"></i>
        <span>${room.averageRating || 0}/5</span>
        <small class="text-muted">(${room.reviewCount || 0})</small>
      </td>
      <td>
        ${room.owner?.name || 'Inconnu'}<br>
        <small>${room.owner?.email || ''}</small>
      </td>
      <td>
        <span class="badge ${room.available !== false ? 'bg-success' : 'bg-danger'}">
          ${room.available !== false ? 'Disponible' : 'Indisponible'}
        </span>
      </td>
      <td>
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-primary" onclick="window.editRoom('${room._id}')">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn btn-outline-danger" onclick="window.deleteRoom('${room._id}')">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
  
  document.getElementById('rooms-table').innerHTML = html || `
    <tr><td colspan="8" class="text-center text-muted">Aucune salle</td></tr>
  `;
}


function searchRooms() {
  const term = document.getElementById('room-search').value.toLowerCase();
  const filtered = allRooms.filter(room => 
    room.title.toLowerCase().includes(term) ||
    (room.description || '').toLowerCase().includes(term) ||
    (room.location?.address || '').toLowerCase().includes(term)
  );
  renderRoomsTable(filtered);
}


async function loadUsers() {
  try {
    const res = await fetch(`${API}/auth/users`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (res.ok) {
      allUsers = await res.json();
      renderUsersTable(allUsers);
    } else {
      throw new Error(`Erreur ${res.status}`);
    }
  } catch (error) {
    console.error("Erreur chargement utilisateurs:", error);
    document.getElementById('users-table').innerHTML = `
      <tr><td colspan="7" class="text-center text-danger">Erreur: ${error.message}</td></tr>
    `;
  }
}

function renderUsersTable(users) {
  const html = users.map(user => `
    <tr>
      <td><strong>${user.name || 'Non renseigné'}</strong></td>
      <td>${user.email || 'N/A'}</td>
      <td>
        <span class="badge ${getRoleBadgeClass(user.role)}">
          ${getRoleText(user.role)}
        </span>
      </td>
      <td>${new Date(user.createdAt || Date.now()).toLocaleDateString('fr-FR')}</td>
      <td>
        <span class="badge ${user.active !== false ? 'bg-success' : 'bg-danger'}">
          ${user.active !== false ? 'Actif' : 'Inactif'}
        </span>
      </td>
      <td><small class="text-muted">${user._id?.substring(0, 8) || 'N/A'}...</small></td>
      <td>
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-primary" onclick="window.editUser('${user._id}')">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn btn-outline-warning" onclick="window.toggleUserStatus('${user._id}', ${!user.active})">
            <i class="fas ${user.active ? 'fa-ban' : 'fa-check'}"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
  
  document.getElementById('users-table').innerHTML = html || `
    <tr><td colspan="7" class="text-center text-muted">Aucun utilisateur</td></tr>
  `;
}


function searchUsers() {
  const term = document.getElementById('user-search').value.toLowerCase();
  const filtered = allUsers.filter(user => 
    (user.name || '').toLowerCase().includes(term) ||
    (user.email || '').toLowerCase().includes(term) ||
    (user.role || '').toLowerCase().includes(term)
  );
  renderUsersTable(filtered);
}

// Charger les avis
async function loadReviews(filterStatus = '') {
  try {
    const url = `${API}/reviews/admin${filterStatus ? `?status=${filterStatus}` : ''}`;
    const res = await fetch(url, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (res.ok) {
      const data = await res.json();
      allReviews = data.reviews || data || [];
      renderReviewsTable(allReviews);
    } else {
      throw new Error(`Erreur ${res.status}`);
    }
  } catch (error) {
    console.error("Erreur chargement avis:", error);
    document.getElementById('reviews-table-container').innerHTML = `
      <div class="alert alert-danger">
        Erreur: ${error.message}<br>
        <small>Créez d'abord des avis depuis l'interface client</small>
      </div>
    `;
  }
}

// Afficher le tableau des avis
function renderReviewsTable(reviews) {
  if (reviews.length === 0) {
    document.getElementById('reviews-table-container').innerHTML = `
      <div class="text-center py-5">
        <i class="fas fa-comments fa-3x text-muted mb-3"></i>
        <h5 class="text-muted">Aucun avis à modérer</h5>
        <p class="text-muted">Les avis apparaitront ici une fois que les clients auront laissé des commentaires.</p>
      </div>
    `;
    return;
  }
  
  const html = `
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Salle</th>
            <th>Client</th>
            <th>Note</th>
            <th>Commentaire</th>
            <th>Statut</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${reviews.map(review => `
            <tr>
              <td>${review.room?.title || 'Salle'}</td>
              <td>
                ${review.user?.name || 'Anonyme'}<br>
                <small>${review.user?.email || ''}</small>
              </td>
              <td>
                <span class="text-warning">
                  ${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}
                </span>
                <small>(${review.rating}/5)</small>
              </td>
              <td>${review.comment}</td>
              <td>
                <span class="badge ${getReviewStatusBadgeClass(review.status)}">
                  ${getReviewStatusText(review.status)}
                </span>
              </td>
              <td>${new Date(review.createdAt).toLocaleDateString('fr-FR')}</td>
              <td>
                ${review.status === 'pending' ? `
                  <button class="btn btn-sm btn-success" onclick="window.moderateReview('${review._id}', 'approved')">
                    <i class="fas fa-check"></i>
                  </button>
                  <button class="btn btn-sm btn-danger" onclick="window.moderateReview('${review._id}', 'rejected')">
                    <i class="fas fa-times"></i>
                  </button>
                ` : ''}
                <button class="btn btn-sm btn-outline-danger" onclick="window.deleteReview('${review._id}')">
                  <i class="fas fa-trash"></i>
                </button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
  
  document.getElementById('reviews-table-container').innerHTML = html;
}


function filterReviews(status) {
  loadReviews(status);
}


function getStatusBadgeClass(status) {
  switch(status) {
    case 'pending': return 'bg-warning text-dark';
    case 'confirmed': return 'bg-success';
    case 'cancelled': return 'bg-danger';
    default: return 'bg-secondary';
  }
}

function getStatusText(status) {
  const texts = {
    pending: 'En attente',
    confirmed: 'Confirmée',
    cancelled: 'Annulée'
  };
  return texts[status] || status;
}

function getRoleBadgeClass(role) {
  switch(role) {
    case 'admin': return 'bg-danger';
    case 'owner': return 'bg-warning text-dark';
    case 'client': return 'bg-info';
    default: return 'bg-secondary';
  }
}

function getRoleText(role) {
  const texts = {
    admin: 'Administrateur',
    owner: 'Propriétaire',
    client: 'Client'
  };
  return texts[role] || role;
}

function getReviewStatusBadgeClass(status) {
  switch(status) {
    case 'approved': return 'bg-success';
    case 'pending': return 'bg-warning text-dark';
    case 'rejected': return 'bg-danger';
    default: return 'bg-secondary';
  }
}

function getReviewStatusText(status) {
  const texts = {
    approved: 'Approuvé',
    pending: 'En attente',
    rejected: 'Rejeté'
  };
  return texts[status] || status;
}

window.showSection = showSection;
window.refreshData = function() {
  showSuccess("Données rafraîchies !");
  loadDashboardData();
  const activeSection = document.querySelector('.section-content:not(.d-none)');
  if (activeSection) {
    const sectionId = activeSection.id.replace('-section', '');
    setTimeout(() => showSection(sectionId), 500);
  }
};

window.exportBookings = function() {
  if (allBookings.length === 0) {
    showWarning("Aucune donnée à exporter");
    return;
  }
  
  const csv = [
    ['ID', 'Utilisateur', 'Email', 'Salle', 'Début', 'Fin', 'Statut', 'Prix/heure', 'Total'],
    ...allBookings.map(b => {
      const room = allRooms.find(r => r._id === b.room?._id || r._id === b.room);
      const start = new Date(b.startDate);
      const end = new Date(b.endDate);
      const hours = (end - start) / (1000 * 60 * 60);
      const total = room?.price ? room.price * hours : 0;
      
      return [
        b._id,
        b.user?.name || '',
        b.user?.email || '',
        room?.title || '',
        start.toLocaleString('fr-FR'),
        end.toLocaleString('fr-FR'),
        b.status,
        room?.price || '0',
        total.toFixed(2)
      ];
    })
  ].map(row => row.join(',')).join('\n');
  
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `reservations_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  
  showSuccess(` ${allBookings.length} réservations exportées`);
};

window.logout = function() {
  if (confirm("Êtes-vous sûr de vouloir vous déconnecter ?")) {
    localStorage.clear();
    window.location.href = "auth.html";
  }
};

window.editBooking = function(bookingId) {
  const booking = allBookings.find(b => b._id === bookingId);
  if (!booking) {
    showError("Réservation non trouvée");
    return;
  }
  
  document.getElementById('edit-booking-id').value = bookingId;
  document.getElementById('edit-booking-status').value = booking.status;
  
  const modal = new bootstrap.Modal(document.getElementById('editBookingModal'));
  modal.show();
};

window.saveBookingChanges = async function() {
  const bookingId = document.getElementById('edit-booking-id').value;
  const newStatus = document.getElementById('edit-booking-status').value;
  
  try {
    const res = await fetch(`${API}/bookings/${bookingId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status: newStatus })
    });
    
    if (res.ok) {
      showSuccess(' Statut mis à jour !');
      bootstrap.Modal.getInstance(document.getElementById('editBookingModal')).hide();
      loadBookings();
      loadDashboardData();
    } else {
      const data = await res.json();
      showError(` Erreur: ${data.message}`);
    }
  } catch (error) {
    console.error(" Erreur mise à jour:", error);
    showError("Erreur lors de la mise à jour");
  }
};

window.deleteBooking = async function(bookingId) {
  if (!confirm('Supprimer cette réservation ?')) return;
  
  try {
    const res = await fetch(`${API}/bookings/${bookingId}`, {
      method: 'DELETE',
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (res.ok) {
      showSuccess(' Réservation supprimée !');
      loadBookings();
      loadDashboardData();
    }
  } catch (error) {
    console.error(" Erreur suppression:", error);
    showError("Erreur lors de la suppression");
  }
};

window.editRoom = function(roomId) {
  const room = allRooms.find(r => r._id === roomId);
  if (!room) {
    showError("Salle non trouvée");
    return;
  }
  
  const newPrice = prompt("Nouveau prix (DA/heure):", room.price);
  if (!newPrice) return;
  
  const newCapacity = prompt("Nouvelle capacité:", room.capacity);
  if (!newCapacity) return;
  
  fetch(`${API}/rooms/${roomId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      price: parseFloat(newPrice),
      capacity: parseInt(newCapacity)
    })
  })
  .then(res => {
    if (res.ok) {
      showSuccess(' Salle modifiée !');
      loadRooms();
      loadDashboardData();
    }
  })
  .catch(error => {
    console.error(" Erreur:", error);
    showError("Erreur lors de la modification");
  });
};

window.deleteRoom = async function(roomId) {
  if (!confirm("Supprimer cette salle ?")) return;
  
  try {
    const res = await fetch(`${API}/rooms/${roomId}`, {
      method: 'DELETE',
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (res.ok) {
      showSuccess('Salle supprimée !');
      loadRooms();
      loadDashboardData();
    } else {
      const data = await res.json();
      showError(` Erreur: ${data.message}`);
    }
  } catch (error) {
    console.error("Erreur suppression:", error);
    showError("Erreur lors de la suppression");
  }
};

window.editUser = function(userId) {
  const user = allUsers.find(u => u._id === userId);
  if (!user) {
    showError("Utilisateur non trouvé");
    return;
  }
  
  const newRole = prompt("Nouveau rôle:", user.role);
  if (!newRole) return;
  
  fetch(`${API}/auth/users/${userId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ role: newRole })
  })
  .then(res => {
    if (res.ok) {
      showSuccess('Utilisateur modifié !');
      loadUsers();
      loadDashboardData();
    }
  })
  .catch(error => {
    console.error(" Erreur:", error);
    showError("Erreur lors de la modification");
  });
};

window.toggleUserStatus = async function(userId, newStatus) {
  try {
    const res = await fetch(`${API}/auth/users/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ active: newStatus })
    });
    
    if (res.ok) {
      showSuccess(`Utilisateur ${newStatus ? 'activé' : 'désactivé'} !`);
      loadUsers();
      loadDashboardData();
    }
  } catch (error) {
    console.error(" Erreur:", error);
    showError("Erreur lors du changement de statut");
  }
};

window.moderateReview = async function(reviewId, status) {
  if (!confirm(status === 'approved' ? 'Approuver cet avis ?' : 'Rejeter cet avis ?')) return;
  
  try {
    const res = await fetch(`${API}/reviews/${reviewId}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status })
    });
    
    if (res.ok) {
      showSuccess(` Avis ${status === 'approved' ? 'approuvé' : 'rejeté'} !`);
      loadReviews();
      loadDashboardData();
    }
  } catch (error) {
    console.error("Erreur modération:", error);
    showError("Erreur lors de la modération");
  }
};

window.deleteReview = async function(reviewId) {
  if (!confirm("Supprimer cet avis ?")) return;
  
  try {
    const res = await fetch(`${API}/reviews/${reviewId}`, {
      method: 'DELETE',
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (res.ok) {
      showSuccess('Avis supprimé !');
      loadReviews();
      loadDashboardData();
    }
  } catch (error) {
    console.error(" Erreur suppression:", error);
    showError("Erreur lors de la suppression");
  }
};

// Fonctions d'affichage
function showSuccess(message) {
  const alert = document.createElement('div');
  alert.className = 'alert alert-success alert-dismissible fade show position-fixed';
  alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999;';
  alert.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  `;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 3000);
}

function showError(message) {
  const alert = document.createElement('div');
  alert.className = 'alert alert-danger alert-dismissible fade show position-fixed';
  alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999;';
  alert.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  `;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 5000);
}

function showWarning(message) {
  const alert = document.createElement('div');
  alert.className = 'alert alert-warning alert-dismissible fade show position-fixed';
  alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999;';
  alert.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  `;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 3000);
}



async function testEndpoint(url, name) {
  try {
    const res = await fetch(url, {
      headers: token ? { "Authorization": `Bearer ${token}` } : {}
    });
    console.log(`${name}: ${res.status} ${res.statusText}`);
    if (res.ok) {
      const data = await res.json();
      console.log(`${name} data:`, Array.isArray(data) ? `${data.length} items` : data);
    }
  } catch (error) {
    console.error(`${name} error:`, error.message);
  }
}



console.log(" admin.js chargé avec succès");
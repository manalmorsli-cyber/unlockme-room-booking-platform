const API = "http://localhost:3000/api";
const token = localStorage.getItem("token");
const userId = localStorage.getItem("userId");

if (!token) {
  alert("Veuillez vous connecter d'abord");
  window.location.href = "auth.html";
}


document.addEventListener('DOMContentLoaded', function() {
  console.log("Owner dashboard initialisé");
  loadOwnerStats();
  loadRooms();
  loadBookings();
  loadReviews();
});


async function loadOwnerStats() {
  try {
    console.log("Chargement des statistiques...");
    
    const [bookingsRes, roomsRes, reviewsRes] = await Promise.all([
      fetch(`${API}/bookings/owner`, {
        headers: { "Authorization": `Bearer ${token}` }
      }),
      fetch(`${API}/rooms/my`, {
        headers: { "Authorization": `Bearer ${token}` }
      }),
      fetch(`${API}/reviews/owner`, {
        headers: { "Authorization": `Bearer ${token}` }
      })
    ]);
    
    const bookings = bookingsRes.ok ? await bookingsRes.json() : [];
    const rooms = roomsRes.ok ? await roomsRes.json() : [];
    const reviews = reviewsRes.ok ? await reviewsRes.json() : [];
    
    
    let revenue = 0;
    bookings.forEach(booking => {
      if (booking.status === 'confirmed') {
        const room = rooms.find(r => r._id === booking.room?._id || r._id === booking.room);
        if (room && room.price) {
          const start = new Date(booking.startDate);
          const end = new Date(booking.endDate);
          const hours = (end - start) / (1000 * 60 * 60);
          revenue += room.price * hours;
        }
      }
    });
    
    
    const statsHtml = `
      <div class="row mb-4">
        <div class="col-md-3">
          <div class="card stat-card bg-primary text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h6>Mes salles</h6>
                  <h2>${rooms.length}</h2>
                </div>
                <i class="fas fa-door-closed fa-3x opacity-50"></i>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card stat-card bg-success text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h6>Réservations</h6>
                  <h2>${bookings.length}</h2>
                </div>
                <i class="fas fa-calendar-alt fa-3x opacity-50"></i>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card stat-card bg-warning text-dark">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h6>Avis reçus</h6>
                  <h2>${reviews.length}</h2>
                </div>
                <i class="fas fa-star fa-3x opacity-50"></i>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card stat-card bg-info text-white">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <div>
                  <h6>Revenus</h6>
                  <h2>${revenue.toFixed(2)} da</h2>
                </div>
                <i class="fas fa-euro-sign fa-3x opacity-50"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.getElementById('stats-section').innerHTML = statsHtml;
    
  } catch (error) {
    console.error("Erreur chargement statistiques:", error);
    document.getElementById('stats-section').innerHTML = `
      <div class="alert alert-warning">
        Statistiques non disponibles: ${error.message}
      </div>
    `;
  }
}

async function loadRooms() {
  try {
    console.log("Chargement de mes salles...");
    
    const res = await fetch(`${API}/rooms/my`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (!res.ok) {
      
      const allRes = await fetch(`${API}/rooms`);
      if (!allRes.ok) throw new Error(`Erreur ${allRes.status}`);
      
      const allRooms = await allRes.json();
      const myRooms = allRooms.filter(room => 
        room.owner && (room.owner._id === userId || room.owner === userId)
      );
      
      displayRooms(myRooms);
      return;
    }
    
    const rooms = await res.json();
    displayRooms(rooms);
    
  } catch (error) {
    console.error("Erreur chargement salles:", error);
    document.getElementById('rooms-list').innerHTML = `
      <div class="alert alert-danger">
        Erreur chargement salles: ${error.message}
      </div>
    `;
  }
}

function displayRooms(rooms) {
  const container = document.getElementById('rooms-list');
  
  if (rooms.length === 0) {
    container.innerHTML = `
      <div class="alert alert-info">
        Vous n'avez créé aucune salle.
      </div>
    `;
    return;
  }
  
  container.innerHTML = rooms.map(room => {
    
    const mainImage = room.mainImage || (room.images && room.images.length > 0 ? room.images[0] : null);
    const imageUrl = mainImage || 'https://via.placeholder.com/300x200?text=Salle+de+réunion';
    
    return `
    <div class="card mb-3">
      <div class="row g-0">
        <div class="col-md-4">
          <img src="${imageUrl}" 
               class="img-fluid rounded-start" 
               alt="${room.title}"
               style="height: 200px; object-fit: cover; cursor: pointer;"
               onclick="showRoomGallery('${room._id}')">
          ${room.images && room.images.length > 1 ? 
            `<small class="text-muted d-block mt-1 text-center">
              <i class="fas fa-images"></i> ${room.images.length} photos
            </small>` : ''}
        </div>
        <div class="col-md-8">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <h5 class="card-title">${room.title}</h5>
                <p class="card-text">${room.description || 'Pas de description'}</p>
                
                <div class="row">
                  <div class="col-md-6">
                    <p><i class="fas fa-users text-primary"></i> <strong>Capacité:</strong> ${room.capacity} personnes</p>
                    <p><i class="fas fa-euro-sign text-success"></i> <strong>Prix:</strong> ${room.price}da par heure</p>
                  </div>
                  <div class="col-md-6">
                    <p><i class="fas fa-map-marker-alt text-danger"></i> <strong>Adresse:</strong> ${room.location?.address || 'Non spécifiée'}</p>
                    <p><i class="fas fa-star text-warning"></i> <strong>Note:</strong> 
                      ${room.averageRating > 0 ? 
                        `${'★'.repeat(Math.round(room.averageRating))}${'☆'.repeat(5 - Math.round(room.averageRating))} (${room.averageRating}/5)` : 
                        'Pas encore noté'}
                      ${room.reviewCount > 0 ? `<small class="text-muted">(${room.reviewCount} avis)</small>` : ''}
                    </p>
                  </div>
                </div>
                
                <div class="mt-2">
                  <button class="btn btn-sm btn-outline-info" onclick="manageRoomImages('${room._id}')">
                    <i class="fas fa-images me-1"></i>Gérer les images
                  </button>
                </div>
              </div>
              
              <div class="btn-group">
                <button class="btn btn-sm btn-outline-primary" onclick="editRoom('${room._id}')">
                  <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteRoom('${room._id}')">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    `;
  }).join('');
}


async function createRoom() {
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const capacity = document.getElementById('capacity').value;
  const price = document.getElementById('price').value;
  const address = document.getElementById('address').value;
  const latitude = document.getElementById('latitude').value;
  const longitude = document.getElementById('longitude').value;
  
  
  if (!title || !capacity || !price || !address) {
    alert("Veuillez remplir tous les champs obligatoires (*)");
    return;
  }
  
  if (!latitude || !longitude) {
    const confirmContinue = confirm(
      "Aucun emplacement précis n'a été défini sur la carte. " +
      "Voulez-vous continuer avec une position par défaut (Alger) ?\n\n" +
      "Pour un meilleur référencement, il est recommandé de définir un emplacement précis."
    );
    if (!confirmContinue) {
      return;
    }
  }
  
  
  const amenities = [];
  const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
  checkboxes.forEach(checkbox => {
    amenities.push(checkbox.value);
  });
  
  
  const formData = new FormData();
  
  formData.append('title', title);
  formData.append('description', description);
  formData.append('capacity', capacity);
  formData.append('price', price);
  formData.append('address', address);
  
  
  if (latitude && longitude) {
    formData.append('latitude', latitude);
    formData.append('longitude', longitude);
  }
  
  formData.append('amenities', JSON.stringify(amenities));
  
  
  const imageInput = document.getElementById('roomImages');
  if (imageInput.files.length > 0) {
    for (let i = 0; i < imageInput.files.length; i++) {
      formData.append('images', imageInput.files[i]);
    }
  }
  
  try {
    const res = await fetch(`${API}/rooms`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
        
      },
      body: formData
    });
    
    const data = await res.json();
    
    if (res.ok) {
      alert('Salle créée avec succès !');
      

      clearForm();
      
      loadOwnerStats();
      loadRooms();
      
      const roomsTab = document.getElementById('rooms-tab');
      if (roomsTab) {
        roomsTab.click();
      }
      
    } else {
      alert('Erreur: ' + (data.message || 'Création échouée'));
    }
  } catch (error) {
    console.error("Erreur création salle:", error);
    alert('Erreur de connexion au serveur');
  }
}


function clearForm() {
  if (confirm("Voulez-vous vraiment effacer tous les champs du formulaire ?")) {
    document.getElementById('title').value = '';
    document.getElementById('description').value = '';
    document.getElementById('capacity').value = '10';
    document.getElementById('price').value = '50';
    document.getElementById('address').value = '';
    document.getElementById('latitude').value = '';
    document.getElementById('longitude').value = '';
    document.getElementById('roomImages').value = '';
    
    document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
      checkbox.checked = false;
    });
    
    document.getElementById('imagePreview').innerHTML = '';
    document.getElementById('noImagesMessage').style.display = 'block';
    
    if (typeof clearMapMarker === 'function') {
      clearMapMarker();
    }
  }
}



function previewImages(event) {
  const preview = document.getElementById('imagePreview');
  preview.innerHTML = '';
  
  const files = event.target.files;
  
  for (let i = 0; i < Math.min(files.length, 5); i++) {
    const file = files[i];
    
    if (!file.type.match('image.*')) continue;
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.className = 'img-thumbnail';
      img.style.width = '100px';
      img.style.height = '100px';
      img.style.objectFit = 'cover';
      img.style.margin = '5px';
      
      preview.appendChild(img);
    }
    
    reader.readAsDataURL(file);
  }
}


async function showRoomGallery(roomId) {
  try {
    const res = await fetch(`${API}/rooms/${roomId}`);
    if (!res.ok) throw new Error('Salle non trouvée');
    
    const room = await res.json();
    
    if (!room.images || room.images.length === 0) {
      alert("Cette salle n'a pas d'images");
      return;
    }
    
    const galleryHtml = `
      <div class="modal fade" id="galleryModal-${roomId}" tabindex="-1">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">${room.title} - Galerie</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div id="carousel-${roomId}" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                  ${room.images.map((img, index) => `
                    <div class="carousel-item ${index === 0 ? 'active' : ''}">
                      <img src="${img}" class="d-block w-100" 
                           style="max-height: 70vh; object-fit: contain;"
                           alt="Photo ${index + 1}">
                    </div>
                  `).join('')}
                </div>
                ${room.images.length > 1 ? `
                  <button class="carousel-control-prev" type="button" data-bs-target="#carousel-${roomId}" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carousel-${roomId}" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                  </button>
                ` : ''}
              </div>
              <div class="text-center mt-3">
                <small class="text-muted">${room.images.length} photo(s)</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    
    const oldModal = document.getElementById(`galleryModal-${roomId}`);
    if (oldModal) oldModal.remove();
    
    
    document.body.insertAdjacentHTML('beforeend', galleryHtml);
    
    
    const modal = new bootstrap.Modal(document.getElementById(`galleryModal-${roomId}`));
    modal.show();
    
    
    document.getElementById(`galleryModal-${roomId}`).addEventListener('hidden.bs.modal', function() {
      setTimeout(() => {
        if (document.body.contains(this)) {
          this.remove();
        }
      }, 300);
    });
    
  } catch (error) {
    console.error("Erreur chargement galerie:", error);
    alert("Erreur lors du chargement des images");
  }
}



async function manageRoomImages(roomId) {
  try {
    const res = await fetch(`${API}/rooms/${roomId}`);
    if (!res.ok) throw new Error('Salle non trouvée');
    
    const room = await res.json();
    
    const imagesHtml = room.images && room.images.length > 0 ? 
      room.images.map((img, index) => `
        <div class="col-md-3 mb-3">
          <div class="card">
            <img src="${img}" class="card-img-top" style="height: 150px; object-fit: cover;" alt="Image ${index + 1}">
            <div class="card-body p-2 text-center">
              <small class="d-block">Image ${index + 1}</small>
              ${room.mainImage === img.split('/').pop() ? 
                '<span class="badge bg-success">Principale</span>' : 
                `<button class="btn btn-sm btn-outline-success mt-1" onclick="setMainImage('${roomId}', '${img.split('/').pop()}')">
                  <i class="fas fa-star"></i> Définir
                </button>`
              }
              <button class="btn btn-sm btn-outline-danger mt-1" onclick="deleteRoomImage('${roomId}', '${img.split('/').pop()}')">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </div>
        </div>
      `).join('') : 
      `<div class="col-12 text-center">
        <p class="text-muted">Aucune image pour cette salle</p>
      </div>`;
    
    const modalHtml = `
      <div class="modal fade" id="imagesModal-${roomId}" tabindex="-1">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Gestion des images - ${room.title}</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <h6>Images actuelles</h6>
                <div class="row" id="currentImages-${roomId}">
                  ${imagesHtml}
                </div>
              </div>
              
              <hr>
              
              <div class="mb-3">
                <h6>Ajouter de nouvelles images</h6>
                <input type="file" class="form-control" id="newImages-${roomId}" 
                       multiple accept="image/*">
                <small class="text-muted">Sélectionnez jusqu'à 5 images supplémentaires</small>
                <button class="btn btn-primary mt-2" onclick="uploadMoreImages('${roomId}')">
                  <i class="fas fa-upload me-1"></i>Ajouter les images
                </button>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    `;
    
   
    const oldModal = document.getElementById(`imagesModal-${roomId}`);
    if (oldModal) oldModal.remove();
    
  
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
   
    const modal = new bootstrap.Modal(document.getElementById(`imagesModal-${roomId}`));
    modal.show();
    

    document.getElementById(`imagesModal-${roomId}`).addEventListener('hidden.bs.modal', function() {
      setTimeout(() => {
        if (document.body.contains(this)) {
          this.remove();
        }
      }, 300);
    });
    
  } catch (error) {
    console.error("Erreur gestion images:", error);
    alert("Erreur lors du chargement des images");
  }
}


async function setMainImage(roomId, imageName) {
  if (!confirm("Définir cette image comme image principale ?")) return;
  
  try {
    const res = await fetch(`${API}/rooms/${roomId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ mainImage: imageName })
    });
    
    if (res.ok) {
      alert('Image principale définie !');
      loadRooms();
      
      const modal = bootstrap.Modal.getInstance(document.getElementById(`imagesModal-${roomId}`));
      if (modal) modal.hide();
    } else {
      const data = await res.json();
      alert('Erreur: ' + data.message);
    }
  } catch (error) {
    console.error("Erreur définition image principale:", error);
    alert('Erreur lors de la modification');
  }
}

async function deleteRoomImage(roomId, imageName) {
  if (!confirm("Supprimer cette image ?")) return;
  
  try {
    const res = await fetch(`${API}/rooms/${roomId}/image/${imageName}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (res.ok) {
      alert('Image supprimée !');
     
      manageRoomImages(roomId);
    } else {
      const data = await res.json();
      alert('Erreur: ' + data.message);
    }
  } catch (error) {
    console.error("Erreur suppression image:", error);
    alert('Erreur lors de la suppression');
  }
}

async function uploadMoreImages(roomId) {
  const input = document.getElementById(`newImages-${roomId}`);
  
  if (!input.files || input.files.length === 0) {
    alert("Veuillez sélectionner des images");
    return;
  }
  
  if (input.files.length > 5) {
    alert("Maximum 5 images à la fois");
    return;
  }
  
  const formData = new FormData();
  
  for (let i = 0; i < input.files.length; i++) {
    formData.append('images', input.files[i]);
  }
  
  try {
    const res = await fetch(`${API}/rooms/${roomId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });
    
    const data = await res.json();
    
    if (res.ok) {
      alert('Images ajoutées avec succès !');
      input.value = '';
      
      manageRoomImages(roomId);
    } else {
      alert('Erreur: ' + (data.message || 'Upload échoué'));
    }
  } catch (error) {
    console.error("Erreur upload images:", error);
    alert('Erreur lors de l\'ajout des images');
  }
}


async function loadBookings() {
  try {
    console.log("Chargement des réservations...");
    
    const res = await fetch(`${API}/bookings/owner`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (!res.ok) {
      throw new Error(`Erreur ${res.status}: ${res.statusText}`);
    }
    
    const bookings = await res.json();
    displayBookings(bookings);
    
  } catch (error) {
    console.error("Erreur chargement réservations:", error);
    document.getElementById('bookings-list').innerHTML = `
      <div class="alert alert-danger">
        Erreur chargement réservations: ${error.message}
      </div>
    `;
  }
}

function displayBookings(bookings) {
  const container = document.getElementById('bookings-list');
  
  if (bookings.length === 0) {
    container.innerHTML = `
      <div class="alert alert-info">
        Aucune réservation sur vos salles.
      </div>
    `;
    return;
  }
  
  container.innerHTML = bookings.map(booking => `
    <div class="card mb-3">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <h6 class="card-title">${booking.room?.title || 'Salle inconnue'}</h6>
            
            <p><strong>Client:</strong> ${booking.user?.name || 'Inconnu'} 
              <small class="text-muted">(${booking.user?.email || 'Email inconnu'})</small>
            </p>
            
            <p><strong>Date:</strong> ${new Date(booking.startDate).toLocaleDateString('fr-FR')}</p>
            <p><strong>Heure:</strong> ${new Date(booking.startDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - 
              ${new Date(booking.endDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
            
            <p><strong>Statut:</strong> 
              <span class="badge ${getStatusBadgeClass(booking.status)}">
                ${getStatusText(booking.status)}
              </span>
            </p>
          </div>
          
          <div class="btn-group-vertical">
            ${booking.status === 'pending' ? `
              <button class="btn btn-sm btn-success mb-1" onclick="updateBookingStatus('${booking._id}', 'confirmed')">
                <i class="fas fa-check me-1"></i>Accepter
              </button>
              <button class="btn btn-sm btn-danger" onclick="updateBookingStatus('${booking._id}', 'cancelled')">
                <i class="fas fa-times me-1"></i>Refuser
              </button>
            ` : ''}
            
            <button class="btn btn-sm btn-outline-info mt-1" onclick="viewBookingDetails('${booking._id}')">
              <i class="fas fa-eye me-1"></i>Détails
            </button>
          </div>
        </div>
        
        <small class="text-muted">
          Créée le: ${new Date(booking.createdAt).toLocaleDateString('fr-FR')}
        </small>
      </div>
    </div>
  `).join('');
}


async function loadReviews() {
  try {
    console.log("Chargement des avis...");
    
    const res = await fetch(`${API}/reviews/owner`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (!res.ok) {
      throw new Error(`Erreur ${res.status}: ${res.statusText}`);
    }
    
    const reviews = await res.json();
    displayReviews(reviews);
    
  } catch (error) {
    console.error("Erreur chargement avis:", error);
    document.getElementById('reviews-list').innerHTML = `
      <div class="alert alert-danger">
        Erreur chargement avis: ${error.message}
      </div>
    `;
  }
}

function displayReviews(reviews) {
  const container = document.getElementById('reviews-list');
  
  if (reviews.length === 0) {
    container.innerHTML = `
      <div class="alert alert-info">
        Aucun avis sur vos salles.
      </div>
    `;
    return;
  }
  
  container.innerHTML = reviews.map(review => `
    <div class="card mb-3">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <h6>${review.room?.title || 'Salle'}</h6>
            <p><strong>Client:</strong> ${review.user?.name || 'Anonyme'}</p>
            
            <div class="mb-2">
              <span class="text-warning">
                ${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}
              </span>
              <small class="text-muted ms-2">(${review.rating}/5)</small>
            </div>
            
            <p class="mb-2">${review.comment}</p>
            
            ${review.ownerReply ? `
              <div class="bg-light p-3 rounded mt-2">
                <p class="mb-0"><strong>Votre réponse:</strong> ${review.ownerReply}</p>
              </div>
            ` : ''}
          </div>
          
          <div>
            <span class="badge ${getReviewStatusBadgeClass(review.status)}">
              ${getReviewStatusText(review.status)}
            </span>
          </div>
        </div>
        
        <div class="mt-3">
          ${!review.ownerReply ? `
            <button class="btn btn-sm btn-primary" onclick="replyToReview('${review._id}')">
              <i class="fas fa-reply me-1"></i>Répondre
            </button>
          ` : `
            <button class="btn btn-sm btn-outline-secondary" onclick="replyToReview('${review._id}')">
              <i class="fas fa-edit me-1"></i>Modifier la réponse
            </button>
          `}
        </div>
        
        <small class="text-muted d-block mt-2">
          ${new Date(review.createdAt).toLocaleDateString('fr-FR')}
        </small>
      </div>
    </div>
  `).join('');
}


async function updateBookingStatus(bookingId, status) {
  const action = status === 'confirmed' ? 'accepter' : 'refuser';
  if (!confirm(`Êtes-vous sûr de vouloir ${action} cette réservation ?`)) {
    return;
  }
  
  try {
    const res = await fetch(`${API}/bookings/${bookingId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status })
    });
    
    const data = await res.json();
    
    if (res.ok) {
      alert(`Réservation ${action}ée !`);
      loadBookings();
      loadOwnerStats();
    } else {
      alert(` Erreur: ${data.message || 'Mise à jour échouée'}`);
    }
  } catch (error) {
    console.error("Erreur mise à jour statut:", error);
    alert('Erreur de connexion au serveur');
  }
}


async function viewBookingDetails(bookingId) {
  try {
    const res = await fetch(`${API}/bookings/owner`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (!res.ok) {
      throw new Error(`Erreur ${res.status}`);
    }
    
    const bookings = await res.json();
    const booking = bookings.find(b => b._id === bookingId);
    
    if (!booking) {
      alert("Réservation non trouvée");
      return;
    }
    
 
    let priceInfo = 'Non disponible';
    if (booking.room?.price) {
      const start = new Date(booking.startDate);
      const end = new Date(booking.endDate);
      const hours = (end - start) / (1000 * 60 * 60);
      const total = booking.room.price * hours;
      priceInfo = `${booking.room.price}da/h × ${hours.toFixed(1)}h = ${total.toFixed(2)}da`;
    }
    
    const detailsHtml = `
      <h6>Détails de la réservation</h6>
      <hr>
      
      <p><strong>Salle:</strong> ${booking.room?.title || 'Inconnue'}</p>
      <p><strong>Client:</strong> ${booking.user?.name || 'Inconnu'} (${booking.user?.email || 'Email inconnu'})</p>
      
      <div class="row">
        <div class="col-md-6">
          <p><strong>Date de début:</strong><br>
            ${new Date(booking.startDate).toLocaleDateString('fr-FR')}<br>
            ${new Date(booking.startDate).toLocaleTimeString('fr-FR')}
          </p>
        </div>
        <div class="col-md-6">
          <p><strong>Date de fin:</strong><br>
            ${new Date(booking.endDate).toLocaleDateString('fr-FR')}<br>
            ${new Date(booking.endDate).toLocaleTimeString('fr-FR')}
          </p>
        </div>
      </div>
      
      <p><strong>Statut:</strong> 
        <span class="badge ${getStatusBadgeClass(booking.status)}">
          ${getStatusText(booking.status)}
        </span>
      </p>
      
      <p><strong>Prix:</strong> ${priceInfo}</p>
      
      <p><strong>Créée le:</strong> ${new Date(booking.createdAt).toLocaleString('fr-FR')}</p>
      
      ${booking.status === 'pending' ? `
        <div class="mt-3">
          <button class="btn btn-success me-2" onclick="updateBookingStatus('${booking._id}', 'confirmed'); $('#detailsModal').modal('hide');">
            <i class="fas fa-check me-1"></i>Accepter
          </button>
          <button class="btn btn-danger" onclick="updateBookingStatus('${booking._id}', 'cancelled'); $('#detailsModal').modal('hide');">
            <i class="fas fa-times me-1"></i>Refuser
          </button>
        </div>
      ` : ''}
    `;
    
    document.getElementById('detailsContent').innerHTML = detailsHtml;
    
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    modal.show();
    
  } catch (error) {
    console.error("Erreur détails réservation:", error);
    alert("Erreur lors du chargement des détails");
  }
}


async function replyToReview(reviewId) {
  const currentReply = prompt("Votre réponse (max 500 caractères):");
  if (!currentReply) return;
  
  if (currentReply.length > 500) {
    alert("La réponse ne doit pas dépasser 500 caractères");
    return;
  }
  
  try {
    const res = await fetch(`${API}/reviews/${reviewId}/reply`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ reply: currentReply })
    });
    
    const data = await res.json();
    
    if (res.ok) {
      alert('Réponse envoyée !');
      loadReviews();
    } else {
      alert('Erreur: ' + data.message);
    }
  } catch (error) {
    console.error("Erreur réponse:", error);
    alert("Erreur lors de l'envoi de la réponse");
  }
}


async function editRoom(roomId) {
  try {
    const res = await fetch(`${API}/rooms/${roomId}`);
    if (!res.ok) throw new Error('Salle non trouvée');
    
    const room = await res.json();
    
   
    const modalHtml = `
      <div class="modal fade" id="editRoomModal-${roomId}" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Modifier la salle</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <form id="editRoomForm-${roomId}">
                <div class="mb-3">
                  <label class="form-label">Nom de la salle *</label>
                  <input type="text" class="form-control" id="edit-title-${roomId}" 
                         value="${room.title}" required>
                </div>
                <div class="mb-3">
                  <label class="form-label">Description</label>
                  <textarea class="form-control" id="edit-description-${roomId}" rows="3">${room.description || ''}</textarea>
                </div>
                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Capacité *</label>
                    <input type="number" class="form-control" id="edit-capacity-${roomId}" 
                           value="${room.capacity}" min="1" required>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label class="form-label">Prix (da/heure) *</label>
                    <input type="number" class="form-control" id="edit-price-${roomId}" 
                           value="${room.price}" min="0" step="0.5" required>
                  </div>
                </div>
                <div class="mb-3">
                  <label class="form-label">Adresse *</label>
                  <input type="text" class="form-control" id="edit-address-${roomId}" 
                         value="${room.location?.address || ''}" required>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
              <button type="button" class="btn btn-primary" onclick="saveRoomChanges('${roomId}')">Enregistrer</button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    
    const oldModal = document.getElementById(`editRoomModal-${roomId}`);
    if (oldModal) oldModal.remove();
    
   
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    const modal = new bootstrap.Modal(document.getElementById(`editRoomModal-${roomId}`));
    modal.show();
    
    
    document.getElementById(`editRoomModal-${roomId}`).addEventListener('hidden.bs.modal', function() {
      setTimeout(() => {
        if (document.body.contains(this)) {
          this.remove();
        }
      }, 300);
    });
    
  } catch (error) {
    console.error("Erreur chargement salle:", error);
    alert("Erreur lors du chargement des informations");
  }
}

async function saveRoomChanges(roomId) {
  const title = document.getElementById(`edit-title-${roomId}`).value;
  const description = document.getElementById(`edit-description-${roomId}`).value;
  const capacity = document.getElementById(`edit-capacity-${roomId}`).value;
  const price = document.getElementById(`edit-price-${roomId}`).value;
  const address = document.getElementById(`edit-address-${roomId}`).value;
  
  if (!title || !capacity || !price || !address) {
    alert("Veuillez remplir tous les champs obligatoires");
    return;
  }
  
  try {
    const res = await fetch(`${API}/rooms/${roomId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        title,
        description,
        capacity: parseInt(capacity),
        price: parseFloat(price),
        address
      })
    });
    
    if (res.ok) {
      alert('Salle modifiée avec succès !');
      
     
      const modal = bootstrap.Modal.getInstance(document.getElementById(`editRoomModal-${roomId}`));
      if (modal) modal.hide();
      
      loadRooms();
      loadOwnerStats();
      
    } else {
      const data = await res.json();
      alert('Erreur: ' + data.message);
    }
  } catch (error) {
    console.error("Erreur modification salle:", error);
    alert('Erreur lors de la modification');
  }
}


async function deleteRoom(roomId) {
  if (!confirm("Êtes-vous sûr de vouloir supprimer cette salle ? Cette action supprimera également toutes les images associées.")) return;
  
  try {
    const res = await fetch(`${API}/rooms/${roomId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (res.ok) {
      alert('Salle supprimée !');
      loadRooms();
      loadOwnerStats();
    } else {
      const data = await res.json();
      alert('Erreur: ' + data.message);
    }
  } catch (error) {
    console.error("Erreur suppression salle:", error);
    alert('Erreur lors de la suppression');
  }
}


function getStatusBadgeClass(status) {
  switch(status) {
    case 'pending': return 'bg-warning text-dark';
    case 'confirmed': return 'bg-success';
    case 'cancelled': return 'bg-danger';
    default: return 'bg-secondary';
  }
}

function getStatusText(status) {
  const texts = {
    pending: 'En attente',
    confirmed: 'Confirmée',
    cancelled: 'Annulée'
  };
  return texts[status] || status;
}

function getReviewStatusBadgeClass(status) {
  switch(status) {
    case 'approved': return 'bg-success';
    case 'pending': return 'bg-warning text-dark';
    case 'rejected': return 'bg-danger';
    default: return 'bg-secondary';
  }
}

function getReviewStatusText(status) {
  const texts = {
    approved: 'Approuvé',
    pending: 'En attente',
    rejected: 'Rejeté'
  };
  return texts[status] || status;
}

function logout() {
  localStorage.clear();
  window.location.href = "auth.html";
}
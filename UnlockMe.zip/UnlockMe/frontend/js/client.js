const API = "http://localhost:3000/api";
let roomsData = [];
///ajout our map
let map = null;
let markers = [];
let allRooms = [];
let markerCluster = null;

const BACKEND_URL = "http://localhost:3000";
//let markersLayer;

const token = localStorage.getItem("token");
const userId = localStorage.getItem("userId");

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
  console.log("Client.js initialisé");
  console.log("Token présent:", !!token);
  console.log("User ID:", userId);
  //loadRooms();
  //renderRoomsSlider();
loadBookings();
});

// Vérifier si l'utilisateur est connecté
if (!token) {
  alert("Veuillez vous connecter d'abord");
  window.location.href = "auth.html";
}

////user infos deconnexion
// const logoutBtn = document.getElementsByClassName('btn-outline-danger');

// // Récupérer les infos depuis le localStorage
// const username = localStorage.getItem('name');
// const userEmail = localStorage.getItem('email'); 

// if (logoutBtn) {
//   logoutBtn.title = `username: ${username}\nEmail: ${userEmail}`;
// }

///ajout our map


// Coordonnées des villes algériennes principales
const ALGERIAN_CITIES_COORDS = {
  'alger': { lat: 36.7538, lng: 3.0588, name: 'Alger' },
  'oran': { lat: 35.6971, lng: -0.6337, name: 'Oran' },
  'constantine': { lat: 36.3650, lng: 6.6147, name: 'Constantine' },
  'annaba': { lat: 36.9000, lng: 7.7667, name: 'Annaba' },
  'batna': { lat: 35.5550, lng: 6.1741, name: 'Batna' },
  'blida': { lat: 36.4700, lng: 2.8300, name: 'Blida' },
  'setif': { lat: 36.1900, lng: 5.4100, name: 'Sétif' },
  'sidi bel abbes': { lat: 35.1939, lng: -0.6414, name: 'Sidi Bel Abbès' },
  'biskra': { lat: 34.8500, lng: 5.7333, name: 'Biskra' },
  'tebessa': { lat: 35.4000, lng: 8.1167, name: 'Tebessa' },
  'tiaret': { lat: 35.3667, lng: 1.3167, name: 'Tiaret' },
  'bejaia': { lat: 36.7500, lng: 5.0667, name: 'Bejaïa' },
  'tlemcen': { lat: 34.8828, lng: -1.3167, name: 'Tlemcen' },
  'bechar': { lat: 31.6082, lng: -2.2198, name: 'Bechar' },
  'skikda': { lat: 36.8667, lng: 6.9000, name: 'Skikda' },
  'souk ahras': { lat: 36.2864, lng: 7.9511, name: 'Souk Ahras' },
  'msila': { lat: 35.7058, lng: 4.5419, name: 'M\'Sila' },
  'el oued': { lat: 33.3683, lng: 6.8672, name: 'El Oued' },
  'laghouat': { lat: 33.8000, lng: 2.8650, name: 'Laghouat' },
  'ouargla': { lat: 31.9500, lng: 5.3167, name: 'Ouargla' },
  'mostaganem': { lat: 35.9333, lng: 0.0833, name: 'Mostaganem' },
  'medea': { lat: 36.2675, lng: 2.7500, name: 'Médéa' },
  'tizi ouzou': { lat: 36.7167, lng: 4.0500, name: 'Tizi Ouzou' },
  'jijel': { lat: 36.8206, lng: 5.7667, name: 'Jijel' },
  'saida': { lat: 34.8303, lng: 0.1517, name: 'Saïda' },
  'guelma': { lat: 36.4619, lng: 7.4258, name: 'Guelma' }
};

// Nettoyer le cache de géocodage
function clearGeocodeCache() {
  const keys = Object.keys(localStorage);
  keys.forEach(key => {
    if (key.startsWith('geocode_')) {
      localStorage.removeItem(key);
    }
  });
  console.log("Cache géocodage effacé");
}

async function loadPublicRooms() {
  try {
    clearGeocodeCache();
    
    const res = await fetch(`${API}/rooms`);
    allRooms = await res.json();
    
     ////aff salle deffile
    renderRoomsSlider(allRooms);
    
    
    // Nettoyer les adresses et supprimer les mauvaises coordonnées
    allRooms = allRooms.map(room => {
      if (room.location?.address) {
        room.location.address = room.location.address.trim();
      }
      
      // VÉRIFICATION CRITIQUE : Supprimer les coordonnées par défaut d'Alger
      if (room.location?.lat === 36.75 && room.location?.lng === 3.06) {
        console.log(`Suppression coordonnées par défaut pour: ${room.title}`);
        delete room.location.lat;
        delete room.location.lng;
      }
      
      return room;
    });
    
    debugRooms(allRooms);
    diagnoseAddressIssues();
    //loadPublicRooms(allRooms);
    initMap(allRooms);
  } catch (error) {
    console.error("Erreur:", error);
    const container = document.getElementById('rooms-container');
    container.innerHTML = `
      <div class="alert alert-danger">
        Impossible de charger les salles. Vérifiez la connexion au serveur.
      </div>
    `;
  }
}

function diagnoseAddressIssues() {
  console.log("=== DIAGNOSTIC ADRESSES ===");
  
  allRooms.forEach((room, i) => {
    const addr = room.location?.address || 'N/A';
    const city = detectCityFromAddress(addr);
    const coords = getExactCoordinatesForAddress(addr, room._id);
    
    console.log(`${i+1}. "${addr}" -> Ville: ${city || 'Non détectée'} -> Coord: ${coords.lat}, ${coords.lng}`);
  });
}

function debugRooms(rooms) {
  console.log("=== DEBUG ROOMS ===");
  console.log(`Total salles: ${rooms.length}`);
  
  rooms.forEach((room, index) => {
    console.log(`Salle ${index + 1}: ${room.title}`);
    console.log(`  - Adresse: ${room.location?.address || 'N/A'}`);
    console.log(`  - Lat: ${room.location?.lat || 'N/A'}`);
    console.log(`  - Lng: ${room.location?.lng || 'N/A'}`);
    console.log(`  - Images: ${room.images ? room.images.length : 0} image(s)`);
  });
  
  const roomsWithCoords = rooms.filter(r => r.location?.lat && r.location?.lng);
  console.log(`Salles avec coordonnées: ${roomsWithCoords.length}/${rooms.length}`);
  
  const roomsWithImages = rooms.filter(r => r.images && r.images.length > 0);
  console.log(`Salles avec images: ${roomsWithImages.length}/${rooms.length}`);
}

function initMap(rooms) {
  if (map) {
    map.remove();
  }
  
  // Vue initiale sur l'Algérie
  map = L.map('map').setView([28.0, 2.0], 5);
  
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap'
  }).addTo(map);
  
  markerCluster = L.markerClusterGroup({
    spiderfyOnMaxZoom: true,
    showCoverageOnHover: false,
    zoomToBoundsOnClick: true,
    maxClusterRadius: 50
  });
  
  map.addLayer(markerCluster);
  
  addMarkersWithGeocoding(rooms);

  
  // ✅ ICI
  //markersLayer = L.markerClusterGroup();
  //map.addLayer(markersLayer);
}

// async function addMarkersWithGeocoding(rooms) {
//   console.log("=== GÉOCODAGE ET AJOUT DES MARQUEURS ===");

//   if (markerCluster) markerCluster.clearLayers();
//   markers = [];

//   const geoPromises = rooms.map(async room => {
//     let coords = room.location?.lat && room.location?.lng && !(room.location.lat === 36.75 && room.location.lng === 3.06)
//                  ? { lat: room.location.lat, lng: room.location.lng }
//                  : await getExactCoordinatesForAddress(room.location?.address || '', room._id);

//     if (!coords) return null;

//     room.location = { ...room.location, ...coords };

//     const detectedCity = detectCityFromAddress(room.location.address);
//     const marker = L.marker([coords.lat, coords.lng]);

//     const mainImage = room.mainImage || (room.images && room.images[0]) || 'https://picsum.photos/300/200';

//     // Créer le contenu du popup
//       let popupContent = `
//         <div style="min-width: 250px; max-width: 350px;">
//           <div class="d-flex align-items-start">
//             <div style="width: 80px; margin-right: 10px;">
//               <img src="${imageUrl}" 
//                    style="width: 100%; height: 80px; object-fit: cover; border-radius: 5px;"
//                    alt="${room.title}">
//               ${room.images && room.images.length > 1 ? 
//                 `<small class="text-muted d-block text-center mt-1">
//                   <i class="fas fa-images fa-xs"></i> ${room.images.length} photos
//                 </small>` : ''}
//             </div>
//             <div style="flex: 1;">
//               <strong class="d-block mb-1">${room.title}</strong>
//               <div class="text-success mb-1">${room.price} DA/heure</div>
//               <div class="mb-1">
//                 <i class="fas fa-users text-primary fa-xs"></i> ${room.capacity} pers.
//                 ${room.averageRating > 0 ? 
//                   `<span class="ms-2">
//                     <i class="fas fa-star text-warning fa-xs"></i> ${room.averageRating.toFixed(1)}
//                   </span>` : ''}
//               </div>
//             </div>
//           </div>
//       `;

//     marker.bindPopup(popupContent);
//     return marker;
//   });

//   const results = await Promise.all(geoPromises);

//   results.forEach(marker => {
//     if (marker) {
//       markers.push(marker);
//       markerCluster.addLayer(marker);
//     }
//   });

//   if (markers.length > 0) {
//     const bounds = L.latLngBounds(markers.map(m => m.getLatLng()));
//     map.fitBounds(bounds.pad(0.1));
//   } else {
//     map.setView([28.0, 2.0], 5);
//   }
// }
async function addMarkersWithGeocoding(rooms) {
  console.log("=== GÉOCODAGE ET AJOUT DES MARQUEURS ===");
  
  if (markerCluster) {
    markerCluster.clearLayers();
  }
  markers = [];
  
  // Traiter chaque salle individuellement pour garantir les bonnes coordonnées
  for (const room of rooms) {
    const address = room.location?.address || '';
    console.log(`Traitement salle: "${room.title}" -> Adresse: "${address}"`);
    
    let coords = null;
    
    // 1. Vérifier si la salle a déjà de BONNES coordonnées
    if (room.location?.lat && room.location?.lng) {
      // Vérifier si ce ne sont pas les coordonnées par défaut d'Alger
      if (!(room.location.lat === 36.75 && room.location.lng === 3.06)) {
        coords = {
          lat: room.location.lat,
          lng: room.location.lng
        };
        console.log(`Utilisation coordonnées existantes: ${coords.lat}, ${coords.lng}`);
      }
    }
    
    // 2. Sinon, obtenir les coordonnées exactes
    if (!coords && address.trim() !== '') {
      coords = await getExactCoordinatesForAddress(address, room._id);
      
      // Mettre à jour les coordonnées dans la salle
      if (coords) {
        if (!room.location) room.location = {};
        room.location.lat = coords.lat;
        room.location.lng = coords.lng;
        console.log(`Coordonnées mises à jour: ${coords.lat}, ${coords.lng}`);
      }
    }
    
    // 3. Ajouter le marqueur si on a des coordonnées
    if (coords) {
      const detectedCity = detectCityFromAddress(address);
      const marker = L.marker([coords.lat, coords.lng]);
      
      // Afficher la première image ou une image par défaut
      const mainImage = room.mainImage || (room.images && room.images.length > 0 ? room.images[0] : null);
      const imageUrl = mainImage || 'https://via.placeholder.com/150x100?text=Salle';
      
      // Créer le contenu du popup
      let popupContent = `
        <div style="min-width: 250px; max-width: 350px;">
          <div class="d-flex align-items-start">
            <div style="width: 80px; margin-right: 10px;">
              <img src="${imageUrl}" 
                   style="width: 100%; height: 80px; object-fit: cover; border-radius: 5px;"
                   alt="${room.title}">
              ${room.images && room.images.length > 1 ? 
                `<small class="text-muted d-block text-center mt-1">
                  <i class="fas fa-images fa-xs"></i> ${room.images.length} photos
                </small>` : ''}
            </div>
            <div style="flex: 1;">
              <strong class="d-block mb-1">${room.title}</strong>
              <div class="text-success mb-1">${room.price} DA/heure</div>
              <div class="mb-1">
                <i class="fas fa-users text-primary fa-xs"></i> ${room.capacity} pers.
                ${room.averageRating > 0 ? 
                  `<span class="ms-2">
                    <i class="fas fa-star text-warning fa-xs"></i> ${room.averageRating.toFixed(1)}
                  </span>` : ''}
              </div>
            </div>
          </div>
      `;
      
      if (detectedCity) {
        popupContent += `<div class="text-primary mb-1">
          <i class="fas fa-map-marker-alt fa-xs"></i> ${detectedCity}
        </div>`;
      }
      
      popupContent += `<small class="text-muted">${address || 'Adresse non spécifiée'}</small>`;
      popupContent += `<br> <button class="btn btn-primary" onclick="bookRoom('${room._id}')">
                <i class="fas fa-calendar-plus me-1"></i> Réserver
                </button>`;
      popupContent += `</div>`;
      
      marker.bindPopup(popupContent);
      markers.push(marker);
      markerCluster.addLayer(marker);
      
      console.log(`Marqueur ajouté: ${room.title} à ${coords.lat}, ${coords.lng}`);
    } else {
      console.warn(`Pas de coordonnées pour: ${room.title}`);
    }
  }
  
  // Ajuster la vue de la carte
  if (markers.length > 0) {
    const bounds = L.latLngBounds(markers.map(m => m.getLatLng()));
    map.fitBounds(bounds.pad(0.1));
  } else {
    // Vue par défaut sur l'Algérie
    map.setView([28.0, 2.0], 5);
  }
}



// FONCTION CRITIQUE : Obtenir les coordonnées EXACTES pour une adresse
async function getExactCoordinatesForAddress(address, roomId = 'default') {
  if (!address || address.trim() === '') {
    return { lat: 36.75, lng: 3.06 }; // Défaut sur Alger
  }
  
  console.log(`Recherche coordonnées pour: "${address}"`);
  
  // 1. Détecter la ville
  const detectedCity = detectExactCityFromAddress(address);
  console.log(`Ville détectée: ${detectedCity || 'Non détectée'}`);
  
  // 2. Si ville détectée, utiliser ses coordonnées
  if (detectedCity) {
    const cityKey = detectedCity.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (ALGERIAN_CITIES_COORDS[cityKey]) {
      const coords = {
        lat: ALGERIAN_CITIES_COORDS[cityKey].lat,
        lng: ALGERIAN_CITIES_COORDS[cityKey].lng,
        source: 'city_lookup'
      };
      console.log(`Coordonnées ville: ${detectedCity} -> ${coords.lat}, ${coords.lng}`);
      return coords;
    }
  }
  
  // 3. Sinon, géocoder l'adresse
  try {
    const cleanAddress = normalizeAddressForGeocoding(address);
    const cacheKey = `geocode_${cleanAddress}`;
    const cached = localStorage.getItem(cacheKey);
    
    if (cached) {
      console.log(`Utilisation cache pour "${cleanAddress}"`);
      const parsed = JSON.parse(cached);
      parsed.source = 'cache';
      return parsed;
    }
    
    console.log(`Géocodage API pour: "${cleanAddress}"`);
    
    // Préparer la requête de géocodage
    let searchQuery = cleanAddress;
    if (detectedCity) {
      searchQuery = detectedCity + ', Algérie';
    } else if (!cleanAddress.includes('algérie') && !cleanAddress.includes('algerie')) {
      searchQuery = cleanAddress + ', Algérie';
    }
    
    console.log(`Requête géocodage: "${searchQuery}"`);
    
 const response = await fetch(`${API}/geocode?address=${encodeURIComponent(address)}`);
const data = await response.json();

if (response.ok && data.length > 0) {
  return {
    lat: parseFloat(data[0].lat),
    lng: parseFloat(data[0].lon),
    source: 'api'
  };
}
    
    console.warn(`Géocodage échoué pour: "${address}"`);
  } catch (error) {
    console.error(`Erreur géocodage:`, error);
  }
  
  // 4. Fallback: utiliser une ville détectée ou défaut
  if (detectedCity) {
    // Essayer de trouver la ville même si pas dans le dictionnaire
    return { lat: 36.75, lng: 3.06, source: 'fallback_city' };
  }
  
  // 5. Dernier recours: coordonnées par défaut d'Alger
  console.log(`Utilisation coordonnées par défaut pour: "${address}"`);
  return { lat: 36.75, lng: 3.06, source: 'default' };
}

// Détection EXACTE de ville
function detectExactCityFromAddress(address) {
  if (!address) return null;
  
  const normalized = address.toLowerCase()
    .replace(/algérie/gi, '')
    .replace(/algerie/gi, '')
    .replace(/alger/gi, '')  // Supprimer aussi "alger" pour éviter confusion
    .trim();
  
  console.log(`Détection ville pour: "${address}" -> normalisé: "${normalized}"`);
  
  // Liste des villes avec leurs noms français 
  const cities = {
    // Bechar doit être vérifié EN PREMIER
    'bechar': ['bechar', 'béchar'],
    'alger': ['alger'],
    'oran': ['oran', 'وهران'],
    'constantine': ['constantine'],
    'annaba': ['annaba', 'عنابة'],
    'batna': ['batna'],
    'blida': ['blida', ],
    'setif': ['setif','sétif'],
    'sidi bel abbes': ['sidi bel abbes','sidi bel abbès'],
    'biskra': ['biskra'],
    'tebessa': ['tebessa','tébessa'],
    'tiaret': ['tiaret'],
    'bejaia': ['bejaia','bejaïa', 'béjaïa'],
    'tlemcen': ['tlemcen'],
    'skikda': ['skikda'],
    'souk ahras': ['souk ahras'],
    'msila': ['msila','m\'sila'],
    'el oued': ['el oued'],
    'laghouat': ['laghouat'],
    'ouargla': ['ouargla'],
    'mostaganem': ['mostaganem'],
    'medea': ['medea','médéa'],
    'tizi ouzou': ['tizi ouzou'],
    'jijel': ['jijel', 'جيجل'],
    'saida': ['saida','saïda'],
    'guelma': ['guelma']
  };
  
  // Diviser l'adresse en mots
  const words = normalized.split(/[,\s]+/).filter(word => word.length > 2);
  
  // Chercher d'abord les mots exacts
  for (const word of words) {
    for (const [city, patterns] of Object.entries(cities)) {
      for (const pattern of patterns) {
        if (word === pattern) {
          console.log(`Détection exacte: "${word}" -> ${city}`);
          return city;
        }
      }
    }
  }
  
  // Chercher dans toute la chaîne (pour les noms composés)
  for (const [city, patterns] of Object.entries(cities)) {
    for (const pattern of patterns) {
      if (normalized.includes(pattern)) {
        console.log(`Détection partielle: "${pattern}" dans "${normalized}" -> ${city}`);
        return city;
      }
    }
  }
  
  console.log(`Aucune ville détectée pour: "${address}"`);
  return null;
}

// Alias pour compatibilité
function detectCityFromAddress(address) {
  const cityKey = detectExactCityFromAddress(address);
  if (cityKey && ALGERIAN_CITIES_COORDS[cityKey]) {
    return ALGERIAN_CITIES_COORDS[cityKey].name;
  }
  return null;
}

function normalizeAddressForGeocoding(address) {
  if (!address) return '';
  
  return address
    .toLowerCase()
    .trim()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s,.-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function clearMarkers() {
  if (markerCluster) {
    markerCluster.clearLayers();
  }
  markers = [];
}


// Fonction pour aller à un slide spécifique
function goToSlide(roomId, slideIndex) {
  const carousel = document.getElementById(`carousel-${roomId}`);
  if (!carousel) return;
  
  const bsCarousel = bootstrap.Carousel.getInstance(carousel);
  if (bsCarousel) {
    bsCarousel.to(slideIndex);
  }
}


// function applyFilters() {
//   console.log("APPLICATION FILTRES ");
  
//   const locationSearch = document.getElementById('location-search')?.value.toLowerCase() || '';
//   const minPrice = parseFloat(document.getElementById('min-price')?.value) || 0;
//   const maxPrice = parseFloat(document.getElementById('max-price')?.value) || Infinity;
//   const minCapacity = parseInt(document.getElementById('min-capacity')?.value) || 0;
  
//   const amenities = [];
//   if (document.getElementById('filter-wifi')?.checked) amenities.push('wifi');
//   if (document.getElementById('filter-projector')?.checked) amenities.push('projector');
//   if (document.getElementById('filter-whiteboard')?.checked) amenities.push('whiteboard');
//   if (document.getElementById('filter-air-conditioning')?.checked) amenities.push('air-conditioning');
//   if (document.getElementById('filter-coffee')?.checked) amenities.push('coffee');
//   if (document.getElementById('filter-parking')?.checked) amenities.push('parking');
  
//   filterAndDisplayRooms({
//     location: locationSearch,
//     minPrice,
//     maxPrice,
//     minCapacity,
//     amenities
//   });
// }
// function applyFilters() {
//   const location = document.getElementById('location-search').value.toLowerCase();
//   const minPrice = Number(document.getElementById('min-price').value) || 0;
//   const maxPrice = Number(document.getElementById('max-price').value) || Infinity;
//   const minCapacity = Number(document.getElementById('min-capacity').value) || 0;

//   const filteredRooms = allRooms.filter(room => {
//     const address = (room.address || '').toLowerCase();
//     const price = room.price || 0;
//     const capacity = room.capacity || 0;

//     return (
//       address.includes(location) &&
//       price >= minPrice &&
//       price <= maxPrice &&
//       capacity >= minCapacity
//     );
//   });

//   // IMPORTANT : on nettoie AVANT
//   clearMapMarkers();

//   // afficher seulement les salles filtrées
//   // displayRooms(filteredRooms);
//   // addMarkers(filteredRooms);

//   // recentrer SUR LE FILTRE
//   if (filteredRooms.length > 0) {
//     fitMapToRooms(filteredRooms);
//   }
// }
function applyFilters() {
  console.log("APPLICATION FILTRES");

  const location = document.getElementById('location-search').value.toLowerCase();
  const minPrice = Number(document.getElementById('min-price').value) || 0;
  const maxPrice = Number(document.getElementById('max-price').value) || Infinity;
  const minCapacity = Number(document.getElementById('min-capacity').value) || 0;

  const filteredRooms = allRooms.filter(room => {
    const address = room.location?.address?.toLowerCase() || '';
    const title = room.title?.toLowerCase() || '';
    const price = room.price || 0;
    const capacity = room.capacity || 0;

    return (
      (address.includes(location) || title.includes(location)) &&
      price >= minPrice &&
      price <= maxPrice &&
      capacity >= minCapacity
    );
  });

  console.log("Salles filtrées:", filteredRooms.length);

  // Mettre à jour la LISTE
  //renderRoomsList(filteredRooms);

   // Mettre à jour le slider
  renderRoomsSlider(filteredRooms);

  // Mettre à jour la CARTE
  addMarkersWithGeocoding(filteredRooms);
}
//ajt nv client.js
// function renderRoomsSlider(rooms = []) {
//   const slider = document.getElementById('roomSlider');

//   if (!slider) {
//     console.error(" roomSlider introuvable");
//     return;
//   }

//   slider.innerHTML = '';

//   if (rooms.length === 0) {
//     slider.innerHTML = `<p class="text-muted">Aucune salle trouvée</p>`;
//     return;
//   }

//   rooms.forEach(room => {
//     const mainImage =
//    room.mainImage
//     ? `${BACKEND_URL}/${room.mainImage}`
//     : room.images && room.images.length > 0
//       ? `${BACKEND_URL}/${room.images[0]}`
//       : 'https://via.placeholder.com/400x250?text=Salle';

//     const card = document.createElement('div');
//     card.className = 'room-card shadow-sm';

//     card.innerHTML = `
//       <img src="${mainImage}" class="room-image rounded-top"
//      alt="${room.title}"
//      onclick="showRoomGallery('${room._id}')">

//       <div class="p-3 d-flex flex-column h-100">
//         <h5>${room.title}</h5>
//         <p class="text-muted small">
//           ${room.location?.address || ''}
//         </p>

//         <span class="badge bg-success mb-2">
//           ${room.price} DA / h
//         </span>

//         <div class="d-flex gap-2 mt-auto">
//           <button class="btn btn-sm btn-outline-secondary"
//                   onclick="showRoomGallery('${room._id}')">
//             <i class="fas fa-images"></i>
//           </button>

//           <button class="btn btn-sm btn-outline-info"
//                   onclick="showRoomReviews('${room._id}')">
//             <i class="fas fa-star"></i>
//           </button>

//           <button class="btn btn-sm btn-primary"
//                   onclick="bookRoom('${room._id}')">
//             Réserver
//           </button>
//         </div>
//       </div>
//     `;

//     slider.appendChild(card);
//   });
// }

//fin


// function clearMapMarkers() {
//   if (markersLayer) {
//     markersLayer.clearLayers();
//   }
// }


// function fitMapToRooms(rooms) {
//   const bounds = [];

//   rooms.forEach(room => {
//     if (room.lat && room.lng) {
//       bounds.push([room.lat, room.lng]);
//     }
//   });

//   if (bounds.length > 0) {
//     map.fitBounds(bounds, { padding: [50, 50] });
//   }
// }



function filterAndDisplayRooms(filters = {}) {
  let filteredRooms = allRooms;
  
  filteredRooms = filteredRooms.filter(room => {
    if (filters.location && filters.location.trim() !== '') {
      const searchTerm = filters.location.toLowerCase().trim();
      const address = room.location?.address?.toLowerCase() || '';
      const city = detectCityFromAddress(room.location?.address)?.toLowerCase() || '';
      const title = room.title?.toLowerCase() || '';
      const description = room.description?.toLowerCase() || '';
      
      if (!address.includes(searchTerm) && 
          !city.includes(searchTerm) && 
          !title.includes(searchTerm) && 
          !description.includes(searchTerm)) {
        return false;
      }
    }
    
    if (room.price < filters.minPrice || room.price > filters.maxPrice) {
      return false;
    }
    
    if (room.capacity < filters.minCapacity) {
      return false;
    }
    
    if (filters.amenities && filters.amenities.length > 0) {
      if (!room.amenities || !Array.isArray(room.amenities)) {
        return false;
      }
      
      const hasAllAmenities = filters.amenities.every(amenity => 
        room.amenities.includes(amenity)
      );
      
      if (!hasAllAmenities) {
        return false;
      }
    }
    
    return true;
  });
  
  console.log("Salles filtrées:", filteredRooms.length);
  
  if (filteredRooms.length === 0) {
    document.getElementById('rooms-container').innerHTML = `
      <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i>
        Aucune salle ne correspond à vos critères de recherche.
        <button class="btn btn-sm btn-outline-primary ms-2" onclick="resetFilters()">
          Réinitialiser les filtres
        </button>
      </div>
    `;
  } else {
    loadPublicRooms(filteredRooms);
  }
  
  updateMapWithFilteredRooms(filteredRooms);
}

function updateMapWithFilteredRooms(rooms) {
  addMarkersWithGeocoding(rooms);
}

function resetFilters() {
  document.getElementById('location-search').value = '';
  document.getElementById('min-price').value = '';
  document.getElementById('max-price').value = '';
  document.getElementById('min-capacity').value = '';
  
  document.getElementById('filter-wifi').checked = false;
  document.getElementById('filter-projector').checked = false;
  document.getElementById('filter-whiteboard').checked = false;
  document.getElementById('filter-air-conditioning').checked = false;
  document.getElementById('filter-coffee').checked = false;
  document.getElementById('filter-parking').checked = false;
  
  loadPublicRooms(allRooms);
  updateMapWithFilteredRooms(allRooms);
}

function addResetButton() {
  const filterCard = document.querySelector('.card-body');
  if (filterCard && !document.getElementById('reset-filters-btn')) {
    const resetButton = document.createElement('button');
    resetButton.id = 'reset-filters-btn';
    resetButton.className = 'btn btn-secondary w-100 mt-2';
    resetButton.innerHTML = '<i class="fas fa-redo me-1"></i>Réinitialiser les filtres';
    resetButton.onclick = resetFilters;
    filterCard.appendChild(resetButton);
  }
}

// Ajouter des filtres d'équipements supplémentaires
function addAmenityFilters() {
  const amenitiesSection = document.querySelector('.mb-3:has(#filter-whiteboard)');
  if (amenitiesSection) {
    const extraAmenities = `
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="air-conditioning" id="filter-air-conditioning">
        <label class="form-check-label" for="filter-air-conditioning">
          <i class="fas fa-snowflake text-primary me-1"></i>Climatisation
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="coffee" id="filter-coffee">
        <label class="form-check-label" for="filter-coffee">
          <i class="fas fa-coffee text-primary me-1"></i>Café/Thé
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="parking" id="filter-parking">
        <label class="form-check-label" for="filter-parking">
          <i class="fas fa-parking text-primary me-1"></i>Parking
        </label>
      </div>
    `;
    amenitiesSection.insertAdjacentHTML('beforeend', extraAmenities);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  console.log("Chargement de la page d'accueil...");
  loadPublicRooms();
  addResetButton();
  addAmenityFilters();
  
  // Ajouter un bouton de rafraîchissement
  const mapSection = document.querySelector('#map').parentElement;
  const refreshBtn = document.createElement('button');
  refreshBtn.className = 'btn btn-sm btn-outline-primary mb-2';
  refreshBtn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>Actualiser la carte';
  refreshBtn.onclick = function() {
    loadPublicRooms();
    showSuccess('Carte actualisée !');
  };
  mapSection.insertBefore(refreshBtn, mapSection.firstChild);
});

// Fonction d'affichage des notifications
function showSuccess(message) {
  const alert = document.createElement('div');
  alert.className = 'alert alert-success alert-dismissible fade show position-fixed';
  alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
  alert.innerHTML = `
    <i class="fas fa-check-circle me-2"></i>${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  `;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 3000);
}

window.applyFilters = applyFilters;
window.resetFilters = resetFilters;
//window.showRoomGallery = showRoomGallery;
//window.showRoomReviews = showRoomReviews;
window.goToSlide = goToSlide;


function showRoomGallery(roomId) {
  const room = allRooms.find(r => r._id === roomId);
  if (!room) {
    alert("Salle non trouvée");
    return;
  }
  
  if (!room.images || room.images.length === 0) {
    alert("Cette salle n'a pas d'images");
    return;
  }
  
  const galleryHtml = `
    <div class="modal fade" id="galleryModal-${roomId}" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              <i class="fas fa-images me-2"></i>${room.title} - Galerie
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div id="carousel-${roomId}" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                ${room.images.map((img, index) => `
                  <div class="carousel-item ${index === 0 ? 'active' : ''}">
                    <div class="text-center">
                      <img src="${img}" 
                           class="img-fluid rounded" 
                           style="max-height: 60vh; object-fit: contain;"
                           alt="Image ${index + 1} de ${room.title}">
                    </div>
                    <div class="text-center mt-3">
                      <span class="badge bg-dark">Image ${index + 1}/${room.images.length}</span>
                    </div>
                  </div>
                `).join('')}
              </div>
              
              ${room.images.length > 1 ? `
                <button class="carousel-control-prev" type="button" data-bs-target="#carousel-${roomId}" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon bg-dark rounded-circle p-2"></span>
                  <span class="visually-hidden">Précédent</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carousel-${roomId}" data-bs-slide="next">
                  <span class="carousel-control-next-icon bg-dark rounded-circle p-2"></span>
                  <span class="visually-hidden">Suivant</span>
                </button>
              ` : ''}
            </div>
            
            <div class="mt-4">
              <div class="row" id="thumbnails-${roomId}">
                ${room.images.map((img, index) => `
                  <div class="col-2 mb-2">
                    <img src="${img}" 
                         class="img-thumbnail ${index === 0 ? 'border-primary' : ''}" 
                         style="cursor: pointer; height: 60px; object-fit: cover;"
                         onclick="goToSlide('${roomId}', ${index})"
                         alt="Miniature ${index + 1}">
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
              <i class="fas fa-times me-1"></i>Fermer
            </button>
            
          </div>
        </div>
      </div>
    </div>
  `;
  
  
  const oldModal = document.getElementById(`galleryModal-${roomId}`);
  if (oldModal) oldModal.remove();
  
  
  document.body.insertAdjacentHTML('beforeend', galleryHtml);
  
  
  const modal = new bootstrap.Modal(document.getElementById(`galleryModal-${roomId}`));
  modal.show();
  
 
  const carousel = document.getElementById(`carousel-${roomId}`);
  if (carousel) {
    carousel.addEventListener('slide.bs.carousel', function (event) {
      const thumbnails = document.querySelectorAll(`#thumbnails-${roomId} .img-thumbnail`);
      thumbnails.forEach((thumb, index) => {
        thumb.classList.toggle('border-primary', index === event.to);
      });
    });
  }
  
  
  document.getElementById(`galleryModal-${roomId}`).addEventListener('hidden.bs.modal', function() {
    setTimeout(() => {
      if (document.body.contains(this)) {
        this.remove();
      }
    }, 300);
  });
}




function renderRoomsSlider(rooms = []) {
  const slider = document.getElementById('roomSlider');

  if (!slider) {
    console.warn("roomSlider introuvable dans le DOM");
    return;
  }

  slider.innerHTML = '';

  rooms.forEach(room => {
    const detectedCity = detectCityFromAddress(room.location?.address);

   
    const mainImage = room.mainImage || (room.images && room.images[0]) || 
                      'https://via.placeholder.com/300x200?text=Salle+de+réunion';

    
    const amenitiesBadges = room.amenities && room.amenities.length > 0 ? 
      room.amenities.map(amenity => {
        const icons = {
          'wifi': 'fa-wifi',
          'projector': 'fa-video',
          'whiteboard': 'fa-chalkboard',
          'air-conditioning': 'fa-snowflake',
          'coffee': 'fa-coffee',
          'parking': 'fa-parking'
        };
        return `<span class="badge bg-light text-dark me-1" title="${amenity}">
                  <i class="fas ${icons[amenity] || 'fa-check'} fa-xs me-1"></i>${amenity}
                </span>`;
      }).join('') : '';

    
    const cardHtml = `
      <div class="room-card shadow-sm">
        <img src="${mainImage}" class="room-image rounded-top" alt="${room.title}" onclick="showRoomGallery('${room._id}')">
        <div class="p-3">
          <h5 class="mb-1">${room.title}</h5>
          <div class="text-success mb-2">${room.price} DA/h</div>
          <div class="mb-2">
            <i class="fas fa-users me-1"></i>${room.capacity} pers.
            ${room.averageRating > 0 ? `<span class="ms-2">
              <i class="fas fa-star text-warning fa-xs"></i> ${room.averageRating.toFixed(1)}
            </span>` : ''}
          </div>
          ${detectedCity ? `<div class="text-primary mb-2">
            <i class="fas fa-map-marker-alt fa-xs"></i> ${detectedCity}
          </div>` : ''}
          <div class="mb-2">
            ${amenitiesBadges}
          </div>
          <div class="d-flex gap-2 mt-3">
            <button class="btn btn-sm btn-outline-secondary" onclick="showRoomGallery('${room._id}')">
              <i class="fas fa-images me-1"></i>Voir images
            </button>

            <button class="btn btn-primary" onclick="bookRoom('${room._id}')">
                  <i class="fas fa-calendar-plus me-1"></i> Réserver
                </button>

            <button class="btn btn-sm btn-outline-info" onclick="showRoomReviews('${room._id}')">
              <i class="fas fa-star me-1"></i> avis
            </button>


          </div>
        </div>
      </div>
    `;

    slider.insertAdjacentHTML('beforeend', cardHtml);
  });
}



let currentOffset = 0;
function scrollSlider(direction) {
  const slider = document.getElementById('roomSlider');
  const cardWidth = slider.children[0].offsetWidth + 15; // largeur + gap
  const wrapper = document.querySelector('.room-slider-wrapper');
  const maxOffset = slider.scrollWidth - wrapper.offsetWidth;

  currentOffset += direction * cardWidth * 2; // defiler 2 cartes à la fois
  if (currentOffset < 0) currentOffset = 0;
  if (currentOffset > maxOffset) currentOffset = maxOffset;

  slider.style.transform = `translateX(-${currentOffset}px)`;
}


window.bookRoom = async function(roomId) {
  console.log("Tentative réservation salle:", roomId);
  
  if (!token) {
    alert("Veuillez vous reconnecter");
    window.location.href = "auth.html";
    return;
  }

  
  const today = new Date();
  const defaultDate = new Date(today);
  defaultDate.setDate(today.getDate() + 7); 
  
  const startDateStr = prompt(
    "Date de début (format: AAAA-MM-JJ HH:MM)\nExemple: 2025-01-20 09:00",
    `${defaultDate.getFullYear()}-${(defaultDate.getMonth() + 1).toString().padStart(2, '0')}-${defaultDate.getDate().toString().padStart(2, '0')} 09:00`
  );
  
  const endDateStr = prompt(
    "Date de fin (format: AAAA-MM-JJ HH:MM)\nExemple: 2025-01-20 12:00",
    `${defaultDate.getFullYear()}-${(defaultDate.getMonth() + 1).toString().padStart(2, '0')}-${defaultDate.getDate().toString().padStart(2, '0')} 12:00`
  );
  
  if (!startDateStr || !endDateStr) {
    alert("Dates requises");
    return;
  }

  // Convertir en format ISO
  const startISO = new Date(startDateStr).toISOString();
  const endISO = new Date(endDateStr).toISOString();

  try {
    console.log("Envoi réservation...", {
      room: roomId,
      startDate: startISO,
      endDate: endISO
    });

    const res = await fetch(`${API}/bookings`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({
        room: roomId,
        startDate: startISO,
        endDate: endISO
      })
    });

    const data = await res.json();
    console.log("Réponse réservation:", data);

    if (!res.ok) {
      throw new Error(data.message || `Erreur ${res.status}`);
    }

    alert(" Réservation créée avec succès !");
    loadBookings(); 
    
  } catch (error) {
    console.error("Erreur réservation:", error);
    alert(" Erreur réservation: " + error.message);
  }
};

window.loadBookings = async function() {
  console.log("Chargement de mes réservations...");
  
  try {
    const res = await fetch(`${API}/bookings/me`, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    });

    if (!res.ok) {
      if (res.status === 401) {
        alert("Session expirée, veuillez vous reconnecter");
        window.location.href = "auth.html";
        return;
      }
      throw new Error(`Erreur ${res.status}: ${res.statusText}`);
    }

    const bookings = (await res.json()) || [];

    console.log("Mes réservations:", bookings);

    if (bookings.length === 0) {
      document.getElementById("bookings-container").innerHTML = `
        <div class="alert alert-info">
          Vous n'avez aucune réservation.
        </div>
      `;
      return;
    }

   document.getElementById("bookings-container").innerHTML = bookings.map(b => {
  const now = new Date();
  const endDate = new Date(b.endDate);
  const canReview = endDate < now && b.status === 'confirmed';

  const statusMap = {
    confirmed: { text: 'Confirmée', class: 'bg-success' },
    pending: { text: 'En attente', class: 'bg-warning text-dark' },
    cancelled: { text: 'Annulée', class: 'bg-danger' }
  };

  const status = statusMap[b.status] || { text: b.status, class: 'bg-secondary' };

  return `
    <div class="card mb-3 p-3">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <h6 class="mb-1">${b.room?.title || 'Salle'}</h6>

          <p class="mb-1">
            <strong>Date :</strong>
            ${new Date(b.startDate).toLocaleDateString()}
          </p>

          <p class="mb-0">
            <strong>Heure :</strong>
            ${new Date(b.startDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            -
            ${new Date(b.endDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>

        <span class="badge ${status.class} px-3 py-2">
          ${status.text}
        </span>
      </div>

      ${canReview ? `
        <div class="mt-3">
          <button class="btn btn-sm btn-info"
            onclick="submitReview('${b._id}', '${b.room?._id || b.room}')">
            <i class="fas fa-star me-1"></i> Laisser un avis
          </button>
        </div>
      ` : ''}
    </div>
  `;
}).join("");

    
  } catch (error) {
    console.error("Erreur chargement réservations:", error);
    document.getElementById("bookings-container").innerHTML = `
      <div class="alert alert-danger">
        Erreur chargement réservations: ${error.message}
      </div>
    `;
  }
};


window.submitReview = async function(bookingId, roomId) {
 
  const modalHtml = `
    <div class="modal fade" id="reviewModal-${bookingId}" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Laisser un avis</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Note (1 à 5 étoiles)</label>
              <div class="star-rating mb-2">
                ${[1,2,3,4,5].map(star => `
                  <span class="star" data-value="${star}" style="font-size: 2em; cursor: pointer; color: #e4e5e9;">
                    ★
                  </span>
                `).join('')}
              </div>
              <input type="hidden" id="rating-${bookingId}" value="0">
            </div>
            <div class="mb-3">
              <label class="form-label">Commentaire</label>
              <textarea class="form-control" id="comment-${bookingId}" rows="4" 
                placeholder="Partagez votre expérience..." maxlength="500"></textarea>
              <small class="text-muted"><span id="charCount-${bookingId}">0</span>/500 caractères</small>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
            <button type="button" class="btn btn-primary" onclick="saveReview('${bookingId}', '${roomId}')">
              Envoyer l'avis
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  
 
  const oldModal = document.getElementById(`reviewModal-${bookingId}`);
  if (oldModal) oldModal.remove();
  
 
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  
  
  const modal = new bootstrap.Modal(document.getElementById(`reviewModal-${bookingId}`));
  modal.show();
  
  
  const stars = document.querySelectorAll(`#reviewModal-${bookingId} .star`);
  stars.forEach(star => {
    star.addEventListener('click', function() {
      const value = parseInt(this.getAttribute('data-value'));
      document.getElementById(`rating-${bookingId}`).value = value;
      
      // Mettre à jour l'affichage des etoiles
      stars.forEach((s, index) => {
        s.style.color = index < value ? '#ffc107' : '#e4e5e9';
      });
    });
  });
  
  // Compteur de caractères
  const textarea = document.getElementById(`comment-${bookingId}`);
  const charCount = document.getElementById(`charCount-${bookingId}`);
  
  textarea.addEventListener('input', function() {
    charCount.textContent = this.value.length;
  });
  
  // Nettoyer après fermeture
  document.getElementById(`reviewModal-${bookingId}`).addEventListener('hidden.bs.modal', function() {
    setTimeout(() => {
      if (document.body.contains(this)) {
        this.remove();
      }
    }, 300);
  });
};

// Sauvegarder l'avis
window.saveReview = async function(bookingId, roomId) {
  const rating = document.getElementById(`rating-${bookingId}`).value;
  const comment = document.getElementById(`comment-${bookingId}`).value;
  
  if (!rating || rating === "0") {
    alert("Veuillez donner une note");
    return;
  }
  
  if (!comment.trim()) {
    alert("Veuillez écrire un commentaire");
    return;
  }
  
  if (comment.length < 10) {
    alert("Le commentaire doit faire au moins 10 caractères");
    return;
  }
  
  try {
    const res = await fetch(`${API}/reviews`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({
        room: roomId,
        booking: bookingId,
        rating: parseInt(rating),
        comment: comment
      })
    });
    
    const data = await res.json();
    
    if (res.ok) {
      alert("Avis soumis avec succès! Il sera visible après modération.");
      
      
      const modal = bootstrap.Modal.getInstance(document.getElementById(`reviewModal-${bookingId}`));
      if (modal) modal.hide();

      loadBookings();
     
      renderRoomsSlider();
    } else {
      alert("Erreur: " + data.message);
    }
  } catch (error) {
    console.error("Erreur soumission avis:", error);
    alert(" Erreur lors de la soumission de l'avis");
  }
};


window.showRoomReviews = async function(roomId) {
  try {
    console.log("Chargement avis pour salle:", roomId);
    
    const res = await fetch(`${API}/reviews/room/${roomId}`);
    if (!res.ok) {
      throw new Error(`Erreur ${res.status}: ${res.statusText}`);
    }
    
    const data = await res.json();
    console.log("Avis chargés:", data);
    
    
    const modalHtml = `
      <div class="modal fade" id="reviewsModal-${roomId}" tabindex="-1">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Avis sur cette salle</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              ${data.reviews && data.reviews.length > 0 ? 
                data.reviews.map(review => `
                  <div class="border-bottom pb-3 mb-3">
                    <div class="d-flex gap-2 mt-3">
                      <div>
                        <strong>${review.user?.name || 'Anonyme'}</strong>
                        <span class="text-warning ms-2">
                          ${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}
                        </span>
                      </div>
                      <small class="text-muted">
                        ${new Date(review.createdAt).toLocaleDateString()}
                      </small>
                    </div>
                    <p class="mt-2 mb-2">${review.comment}</p>
                    ${review.ownerReply ? `
                      <div class="bg-light p-3 rounded mt-2">
                        <div class="d-flex">
                          <i class="fas fa-reply text-success me-2 mt-1"></i>
                          <div>
                            <strong>Réponse du propriétaire:</strong>
                            <p class="mb-0">${review.ownerReply}</p>
                          </div>
                        </div>
                      </div>
                    ` : ''}
                  </div>
                `).join('') : 
                '<p class="text-muted text-center">Aucun avis pour cette salle.</p>'
              }
              
              ${data.totalPages > 1 ? `
                <div class="text-center mt-3">
                  <small class="text-muted">
                    Page ${data.currentPage} sur ${data.totalPages} • 
                    ${data.totalReviews} avis au total
                  </small>
                </div>
              ` : ''}
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
            </div>
          </div>
        </div>
      </div>
    `;
    
   
    const oldModal = document.getElementById(`reviewsModal-${roomId}`);
    if (oldModal) {
      oldModal.remove();
    }
    
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
   
    const modal = new bootstrap.Modal(document.getElementById(`reviewsModal-${roomId}`));
    modal.show();
    
    
    document.getElementById(`reviewsModal-${roomId}`).addEventListener('hidden.bs.modal', function () {
      setTimeout(() => {
        if (document.body.contains(this)) {
          this.remove();
        }
      }, 300);
    });
    
  } catch (error) {
    console.error("Erreur chargement avis:", error);
    alert("Erreur lors du chargement des avis: " + error.message);
  }
};


window.logout = function() {
  localStorage.clear();
  window.location.href = "auth.html";
};

function filterByKeyword(keyword) {
    console.log(`Filtrage par mot-clé: ${keyword}`);
    
    let filteredRooms = allRooms.filter(room => {
        
        const searchText = (room.title + ' ' + room.description + ' ' + (room.amenities ? room.amenities.join(' ') : '')).toLowerCase();

        const keywordMap = {
            'réunion': ['réunion', 'reunion', 'meeting', 'réunions', 'réunions d\'affaires', 'salle de réunion'],
            'fêtes': ['fêtes', 'fete', 'fetes', 'party', 'anniversaire', 'célébration', 'événement'],
            'coworking': ['coworking', 'cowork', 'espace de travail', 'open space', 'bureau partagé']
        };
        
       
        const searchTerms = keywordMap[keyword] || [keyword];
        
        
        return searchTerms.some(term => searchText.includes(term.toLowerCase()));
    });
    
    console.log(`Salles trouvées pour "${keyword}":`, filteredRooms.length);
    
   
    if (filteredRooms.length === 0) {
        
        const slider = document.getElementById('roomSlider');
        slider.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Aucune salle trouvée pour "${keyword}"</h4>
                <button class="btn btn-outline-primary mt-2" onclick="resetKeywordFilters()">
                    Voir toutes les salles
                </button>
            </div>
        `;
    } else {
        renderRoomsSlider(filteredRooms);
    }
    
   
    addMarkersWithGeocoding(filteredRooms);

    highlightActiveKeywordButton(keyword);
}


function resetKeywordFilters() {
    console.log("Réinitialisation des filtres par mot-clé");
    
    
    if (document.getElementById('location-search')) {
        document.getElementById('location-search').value = '';
    }
    if (document.getElementById('min-price')) {
        document.getElementById('min-price').value = '';
    }
    if (document.getElementById('max-price')) {
        document.getElementById('max-price').value = '';
    }
    if (document.getElementById('min-capacity')) {
        document.getElementById('min-capacity').value = '';
    }
    
    
    document.querySelectorAll('.btn-outline-primary').forEach(btn => {
        btn.classList.remove('active');
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-primary');
    });
    
   
    renderRoomsSlider(allRooms);
    addMarkersWithGeocoding(allRooms);
}


function highlightActiveKeywordButton(keyword) {
    
    document.querySelectorAll('.btn-outline-primary').forEach(btn => {
        btn.classList.remove('active');
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-primary');
    });
    
    
    const buttons = document.querySelectorAll('.btn-outline-primary');
    buttons.forEach(btn => {
        if (btn.onclick && btn.onclick.toString().includes(`'${keyword}'`)) {
            btn.classList.remove('btn-outline-primary');
            btn.classList.add('btn-primary', 'active');
        }
    });
}


document.addEventListener('DOMContentLoaded', function() {
    
    
    
    const style = document.createElement('style');
    style.textContent = `
        .btn-outline-primary.active,
        .btn-primary.active {
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.5);
        }
    `;
    document.head.appendChild(style);
});


window.filterByKeyword = filterByKeyword;
window.resetKeywordFilters = resetKeywordFilters;
window.showRoomGallery = showRoomGallery;
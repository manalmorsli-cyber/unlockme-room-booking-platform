// js/map.js
let map = null;
let marker = null;
let geocodeMarker = null;

// Coordonnées par défaut (Alger)
const DEFAULT_COORDS = {
  lat: 36.752887,
  lng: 3.042048,
  zoom: 12
};

// Initialiser la carte
function initMap() {
  console.log("Initialisation de la carte...");
  
  // Créer la carte
  map = L.map('map').setView([DEFAULT_COORDS.lat, DEFAULT_COORDS.lng], DEFAULT_COORDS.zoom);
  
  // Ajouter la couche OpenStreetMap
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19
  }).addTo(map);
  
  // Gérer les clics sur la carte
  map.on('click', function(e) {
    updateMarkerPosition(e.latlng.lat, e.latlng.lng);
  });
  
  // Marqueur initial (si déjà défini)
  const initialLat = parseFloat(document.getElementById('latitude').value) || DEFAULT_COORDS.lat;
  const initialLng = parseFloat(document.getElementById('longitude').value) || DEFAULT_COORDS.lng;
  
  if (initialLat && initialLng) {
    updateMarkerPosition(initialLat, initialLng);
  }
  
  console.log("Carte initialisée");
}

// Mettre à jour la position du marqueur
function updateMarkerPosition(lat, lng) {
  console.log(`Mise à jour marqueur: ${lat}, ${lng}`);
  
  // Mettre à jour les champs de formulaire
  document.getElementById('latitude').value = lat.toFixed(6);
  document.getElementById('longitude').value = lng.toFixed(6);
  
  // Supprimer l'ancien marqueur si existe
  if (marker) {
    map.removeLayer(marker);
  }
  
  // Supprimer le marqueur de géocodage si existe
  if (geocodeMarker) {
    map.removeLayer(geocodeMarker);
    geocodeMarker = null;
  }
  
  // Créer un nouveau marqueur
  marker = L.marker([lat, lng], {
    draggable: true,
    title: 'Emplacement de la salle'
  }).addTo(map);
  
  // Ajouter un popup
  marker.bindPopup(`<b>Emplacement sélectionné</b><br>Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}`).openPopup();
  
  // Centrer la carte sur le marqueur
  map.setView([lat, lng], 16);
  
  // Gérer le déplacement du marqueur
  marker.on('dragend', function(e) {
    const newLatLng = e.target.getLatLng();
    document.getElementById('latitude').value = newLatLng.lat.toFixed(6);
    document.getElementById('longitude').value = newLatLng.lng.toFixed(6);
    
    // Reverse geocoding pour obtenir l'adresse
    reverseGeocode(newLatLng.lat, newLatLng.lng);
  });
  
  // Reverse geocoding pour obtenir l'adresse
  reverseGeocode(lat, lng);
}

// Rechercher une adresse (geocoding)
async function searchAddress() {
  const address = document.getElementById('address').value.trim();
  
  if (!address || address.length < 3) {
    return;
  }
  
  console.log(`Recherche d'adresse: ${address}`);
  
  try {
    // Utiliser Nominatim (OpenStreetMap)
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1&countrycodes=DZ`,
      {
        headers: {
          'User-Agent': 'RoomBookingApp/1.0',
          'Accept': 'application/json'
        }
      }
    );
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.length > 0) {
        const result = data[0];
        const lat = parseFloat(result.lat);
        const lng = parseFloat(result.lon);
        
        console.log(`Adresse trouvée: ${result.display_name}`);
        
        // Mettre à jour l'adresse avec le résultat complet
        document.getElementById('address').value = result.display_name;
        
        // Mettre à jour les coordonnées
        document.getElementById('latitude').value = lat.toFixed(6);
        document.getElementById('longitude').value = lng.toFixed(6);
        
        // Créer un marqueur temporaire pour l'adresse
        if (geocodeMarker) {
          map.removeLayer(geocodeMarker);
        }
        
        geocodeMarker = L.marker([lat, lng], {
          icon: L.icon({
            iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
            shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41]
          })
        }).addTo(map);
        
        geocodeMarker.bindPopup(`<b>Adresse trouvée</b><br>${result.display_name}`).openPopup();
        
        // Centrer la carte
        map.setView([lat, lng], 16);
        
        // Ajouter un cercle de précision
        L.circle([lat, lng], {
          color: 'blue',
          fillColor: '#30f',
          fillOpacity: 0.2,
          radius: 100
        }).addTo(map);
        
      } else {
        alert('Adresse non trouvée. Essayez avec plus de détails.');
      }
    }
  } catch (error) {
    console.error('Erreur géocodage:', error);
    alert('Erreur lors de la recherche d\'adresse');
  }
}

// Reverse geocoding (coordonnées vers adresse)
async function reverseGeocode(lat, lng) {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`,
      {
        headers: {
          'User-Agent': 'RoomBookingApp/1.0',
          'Accept': 'application/json'
        }
      }
    );
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.display_name) {
        // Mettre à jour le champ d'adresse
        document.getElementById('address').value = data.display_name;
        
        // Mettre à jour le popup du marqueur
        if (marker) {
          marker.bindPopup(`<b>${data.display_name}</b><br>Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}`).openPopup();
        }
      }
    }
  } catch (error) {
    console.error('Erreur reverse geocoding:', error);
  }
}

// Centrer sur l'Algérie
function centerOnAlgeria() {
  map.setView([28.0339, 1.6596], 5); // Vue d'ensemble de l'Algérie
  
  // Ajouter des marqueurs pour les principales villes algériennes
  const algerianCities = [
    { name: 'Alger', lat: 36.752887, lng: 3.042048 },
    { name: 'Oran', lat: 35.6971, lng: -0.6337 },
    { name: 'Constantine', lat: 36.3650, lng: 6.6147 },
    { name: 'Annaba', lat: 36.9000, lng: 7.7667 },
    { name: 'Batna', lat: 35.5550, lng: 6.1741 },
    { name: 'Blida', lat: 36.4700, lng: 2.8300 },
    { name: 'Sétif', lat: 36.1900, lng: 5.4100 },
    { name: 'Tlemcen', lat: 34.8828, lng: -1.3167 }
  ];
  
  algerianCities.forEach(city => {
    L.marker([city.lat, city.lng])
      .bindPopup(`<b>${city.name}</b>`)
      .addTo(map);
  });
}

// Utiliser la position actuelle
function useMyLocation() {
  if (!navigator.geolocation) {
    alert('La géolocalisation n\'est pas supportée par votre navigateur');
    return;
  }
  
  navigator.geolocation.getCurrentPosition(
    function(position) {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      
      updateMarkerPosition(lat, lng);
      
      // Ajouter un cercle de précision
      const accuracy = position.coords.accuracy;
      L.circle([lat, lng], {
        color: 'green',
        fillColor: '#0f0',
        fillOpacity: 0.2,
        radius: accuracy
      }).addTo(map);
      
      alert('Position actuelle détectée !');
    },
    function(error) {
      console.error('Erreur géolocalisation:', error);
      alert('Impossible d\'obtenir votre position');
    },
    {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0
    }
  );
}

// Effacer le marqueur
function clearMapMarker() {
  if (marker) {
    map.removeLayer(marker);
    marker = null;
  }
  
  if (geocodeMarker) {
    map.removeLayer(geocodeMarker);
    geocodeMarker = null;
  }
  
  // Réinitialiser les champs
  document.getElementById('latitude').value = '';
  document.getElementById('longitude').value = '';
  document.getElementById('address').value = '';
  
  // Recentrer sur l'Algérie
  centerOnAlgeria();
}

// Initialiser la carte au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
  // Attendre que la carte soit visible dans le DOM
  setTimeout(initMap, 500);
});

// Gérer le changement d'onglet pour réinitialiser la carte
document.addEventListener('DOMContentLoaded', function() {
  const createTab = document.getElementById('create-tab');
  if (createTab) {
    createTab.addEventListener('shown.bs.tab', function() {
      setTimeout(() => {
        if (map) {
          map.invalidateSize();
        } else {
          initMap();
        }
      }, 300);
    });
  }
});